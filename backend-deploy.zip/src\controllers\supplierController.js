const supplierModel = require('../models/supplierModel');
const { asyncHandler, ApiError } = require('../middleware/errorHandler');
const { getTenantId, getTargetTenantId } = require('../utils/tenantHelper');

const getAll = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const search = req.query.search || '';
  const data = await supplierModel.findAll(tenantId, search);
  res.json({ success: true, data });
});

const getById = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const data = await supplierModel.findById(id, tenantId);
  if (!data) throw new ApiError(404, 'Supplier tidak ditemukan');
  res.json({ success: true, data });
});

const create = asyncHandler(async (req, res) => {
  const tenantId = getTargetTenantId(req);
  const kodeSupplier = (req.body.kode_supplier || '').trim();
  const namaSupplier = (req.body.nama_supplier || '').trim();
  const telepon = (req.body.telepon || '').trim() || null;
  const alamat = (req.body.alamat || '').trim() || null;

  if (!kodeSupplier || !namaSupplier) {
    throw new ApiError(400, 'Kode supplier dan nama supplier wajib diisi');
  }

  const existing = await supplierModel.findByKode(kodeSupplier, tenantId);
  if (existing) {
    throw new ApiError(409, `Kode supplier "${kodeSupplier}" sudah digunakan`);
  }

  const id = await supplierModel.create({ tenantId, kodeSupplier, namaSupplier, telepon, alamat });
  const data = await supplierModel.findById(id, tenantId);
  res.status(201).json({ success: true, message: 'Supplier berhasil ditambahkan', data });
});

const update = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const existing = await supplierModel.findById(id, tenantId);
  if (!existing) throw new ApiError(404, 'Supplier tidak ditemukan');

  const kodeSupplier = (req.body.kode_supplier || '').trim();
  const namaSupplier = (req.body.nama_supplier || '').trim();
  const telepon = (req.body.telepon || '').trim() || null;
  const alamat = (req.body.alamat || '').trim() || null;

  if (!kodeSupplier || !namaSupplier) {
    throw new ApiError(400, 'Kode supplier dan nama supplier wajib diisi');
  }

  const checkKode = await supplierModel.findByKode(kodeSupplier, tenantId);
  if (checkKode && checkKode.id !== id) {
    throw new ApiError(409, `Kode supplier "${kodeSupplier}" sudah digunakan oleh supplier lain`);
  }

  await supplierModel.update(id, tenantId, { kodeSupplier, namaSupplier, telepon, alamat });
  const data = await supplierModel.findById(id, tenantId);
  res.json({ success: true, message: 'Supplier berhasil diperbarui', data });
});

const remove = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const existing = await supplierModel.findById(id, tenantId);
  if (!existing) throw new ApiError(404, 'Supplier tidak ditemukan');

  await supplierModel.remove(id, tenantId);
  res.json({ success: true, message: 'Supplier berhasil dihapus' });
});

module.exports = {
  getAll,
  getById,
  create,
  update,
  remove,
};

