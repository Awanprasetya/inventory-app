const customerModel = require('../models/customerModel');
const { asyncHandler, ApiError } = require('../middleware/errorHandler');
const { getTenantId, getTargetTenantId } = require('../utils/tenantHelper');

const getAll = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const search = req.query.search || '';
  const data = await customerModel.findAll(tenantId, search);
  res.json({ success: true, data });
});

const getById = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const data = await customerModel.findById(id, tenantId);
  if (!data) throw new ApiError(404, 'Customer tidak ditemukan');
  res.json({ success: true, data });
});

const create = asyncHandler(async (req, res) => {
  const tenantId = getTargetTenantId(req);
  const kodeCustomer = (req.body.kode_customer || '').trim();
  const namaCustomer = (req.body.nama_customer || '').trim();
  const telepon = (req.body.telepon || '').trim() || null;
  const alamatPengiriman = (req.body.alamat_pengiriman || '').trim() || null;

  if (!kodeCustomer || !namaCustomer) {
    throw new ApiError(400, 'Kode customer dan nama customer wajib diisi');
  }

  const existing = await customerModel.findByKode(kodeCustomer, tenantId);
  if (existing) {
    throw new ApiError(409, `Kode customer "${kodeCustomer}" sudah digunakan`);
  }

  const id = await customerModel.create({ tenantId, kodeCustomer, namaCustomer, telepon, alamatPengiriman });
  const data = await customerModel.findById(id, tenantId);
  res.status(201).json({ success: true, message: 'Customer berhasil ditambahkan', data });
});

const update = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const existing = await customerModel.findById(id, tenantId);
  if (!existing) throw new ApiError(404, 'Customer tidak ditemukan');

  const kodeCustomer = (req.body.kode_customer || '').trim();
  const namaCustomer = (req.body.nama_customer || '').trim();
  const telepon = (req.body.telepon || '').trim() || null;
  const alamatPengiriman = (req.body.alamat_pengiriman || '').trim() || null;

  if (!kodeCustomer || !namaCustomer) {
    throw new ApiError(400, 'Kode customer dan nama customer wajib diisi');
  }

  const checkKode = await customerModel.findByKode(kodeCustomer, tenantId);
  if (checkKode && checkKode.id !== id) {
    throw new ApiError(409, `Kode customer "${kodeCustomer}" sudah digunakan oleh customer lain`);
  }

  await customerModel.update(id, tenantId, { kodeCustomer, namaCustomer, telepon, alamatPengiriman });
  const data = await customerModel.findById(id, tenantId);
  res.json({ success: true, message: 'Customer berhasil diperbarui', data });
});

const remove = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const existing = await customerModel.findById(id, tenantId);
  if (!existing) throw new ApiError(404, 'Customer tidak ditemukan');

  await customerModel.remove(id, tenantId);
  res.json({ success: true, message: 'Customer berhasil dihapus' });
});

module.exports = {
  getAll,
  getById,
  create,
  update,
  remove,
};

