require('dotenv').config();
const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');

const dbConfig = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  multipleStatements: true,
};

const dbName = process.env.DB_NAME || 'inventory';

const sqlFiles = [
  'inventory.sql',
  'migration_users.sql',
  'migration_users_role_varchar.sql',
  'migration_harga.sql',
  'migration_fifo_fefo.sql',
  'migration_products_soft_delete.sql',
  'migration_so_do_po.sql',
  'migration_trans_po_do.sql',
  'migration_po_so_pricing.sql',
  'migration_utang_piutang.sql',
  'migration_accounting.sql',
  'migration_erp_accounting_complete.sql',
  'migration_advanced_inventory_commercial.sql',
  'migration_warehouse_operations_enhancement.sql',
  'migration_multi_warehouse_lots_fix.sql',
  'migration_racks_multi_tenant_fix.sql',
  'migration_saas_multitenancy.sql',
  'migration_multitenant_unique_keys.sql',
  'migration_product_unit_conversion.sql',
  'migration_rbac_permissions.sql',
  'seed.sql',
];

async function runSQLFile(connection, filePath) {
  let content = fs.readFileSync(filePath, 'utf8');

  // Convert CREATE TABLE to CREATE TABLE IF NOT EXISTS safely
  content = content.replace(/CREATE TABLE\s+(?!IF\s+NOT\s+EXISTS)/gi, 'CREATE TABLE IF NOT EXISTS ');

  // Remove CLI-only DELIMITER directives and convert // to ;
  content = content
    .replace(/DELIMITER\s+\/\//gi, '')
    .replace(/DELIMITER\s+;/gi, '')
    .replace(/\/\//g, ';');

  try {
    await connection.query(content);
  } catch (err) {
    // If multi-statement execution throws an error (e.g. duplicate key or table exists), fallback to smart statement execution
    const statements = content
      .split(';')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    for (const stmt of statements) {
      try {
        await connection.query(stmt);
      } catch (innerErr) {
        if (
          innerErr.code === 'ER_TABLE_EXISTS_ERROR' ||
          innerErr.code === 'ER_DUP_FIELDNAME' ||
          innerErr.code === 'ER_DUP_KEYNAME' ||
          innerErr.code === 'ER_CANT_DROP_FIELD_OR_KEY' ||
          innerErr.code === 'ER_FK_DUP_NAME' ||
          innerErr.code === 'ER_DUP_ENTRY' ||
          innerErr.code === 'ER_MULTIPLE_PRI_KEY' ||
          innerErr.code === 'ER_KEY_COLUMN_DOES_NOT_EXITS' ||
          innerErr.errno === 1050 ||
          innerErr.errno === 1060 ||
          innerErr.errno === 1061 ||
          innerErr.errno === 1062 ||
          innerErr.errno === 1068 ||
          innerErr.errno === 1072 ||
          innerErr.errno === 1091 ||
          innerErr.errno === 1826
        ) {
          // Ignore duplicate definitions or already dropped indexes
        } else {
          console.warn(`   [NOTICE]: ${innerErr.message}`);
        }
      }
    }
  }
}

async function main() {
  console.log('==================================================');
  console.log(` Starting database migration for database: "${dbName}"`);
  console.log(` Host: ${dbConfig.host}:${dbConfig.port}, User: ${dbConfig.user}`);
  console.log('==================================================\n');

  let connection;
  try {
    // 1. Connect without selecting database to ensure DB creation
    connection = await mysql.createConnection(dbConfig);
    console.log('[1/4] Connected to MySQL Server successfully.');

    // 2. Create database if not exists
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;`);
    await connection.query(`USE \`${dbName}\`;`);
    console.log(`[2/4] Database "${dbName}" checked/created and selected.`);

    // 3. Run all SQL migration files in order
    console.log('[3/4] Running SQL migrations...');
    const databaseDir = path.join(__dirname, '..', '..', 'database');

    for (const file of sqlFiles) {
      const fullPath = path.join(databaseDir, file);
      if (fs.existsSync(fullPath)) {
        console.log(`   -> Executing: ${file}...`);
        await runSQLFile(connection, fullPath);
      } else {
        console.warn(`   [WARNING] File not found: ${file}`);
      }
    }
    console.log('   ✓ All SQL migration files executed successfully.');

    // 4. Run JS sync migration (Utang & Piutang synchronization)
    console.log('[4/4] Running accounts payable & receivable sync script...');
    const pool = require('../src/config/db');
    await syncUtangPiutang(pool);

    console.log('\n==================================================');
    console.log(' MIGRATION COMPLETED SUCCESSFULLY! 🎉');
    console.log('==================================================');
    process.exit(0);
  } catch (error) {
    console.error('\n[ERROR] Migration failed:', error.message);
    process.exit(1);
  } finally {
    if (connection) {
      await connection.end();
    }
  }
}

async function syncUtangPiutang(pool) {
  try {
    // Check & Add columns if needed
    const [poCols] = await pool.query(
      "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'purchase_orders'"
    );
    const poColNames = poCols.map((c) => c.COLUMN_NAME);

    if (!poColNames.includes('termin_hari')) {
      await pool.query('ALTER TABLE purchase_orders ADD COLUMN termin_hari INT NOT NULL DEFAULT 30 AFTER tanggal_po');
    }
    if (!poColNames.includes('jatuh_tempo')) {
      await pool.query('ALTER TABLE purchase_orders ADD COLUMN jatuh_tempo DATE NULL AFTER termin_hari');
    }

    const [soCols] = await pool.query(
      "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'sales_orders'"
    );
    const soColNames = soCols.map((c) => c.COLUMN_NAME);

    if (!soColNames.includes('termin_hari')) {
      await pool.query('ALTER TABLE sales_orders ADD COLUMN termin_hari INT NOT NULL DEFAULT 30 AFTER tanggal_so');
    }
    if (!soColNames.includes('jatuh_tempo')) {
      await pool.query('ALTER TABLE sales_orders ADD COLUMN jatuh_tempo DATE NULL AFTER termin_hari');
    }

    await pool.query('UPDATE purchase_orders SET jatuh_tempo = DATE_ADD(tanggal_po, INTERVAL termin_hari DAY) WHERE jatuh_tempo IS NULL');
    await pool.query('UPDATE sales_orders SET jatuh_tempo = DATE_ADD(tanggal_so, INTERVAL termin_hari DAY) WHERE jatuh_tempo IS NULL');

    // Sync PO -> accounts_payable
    await pool.query(`
      INSERT INTO accounts_payable (no_tagihan, po_id, supplier_id, tanggal, jatuh_tempo, total_tagihan, total_dibayar, sisa_utang, status, keterangan)
      SELECT 
        CONCAT('AP-', po.no_po) AS no_tagihan,
        po.id AS po_id,
        po.supplier_id,
        po.tanggal_po AS tanggal,
        COALESCE(po.jatuh_tempo, DATE_ADD(po.tanggal_po, INTERVAL 30 DAY)) AS jatuh_tempo,
        po.total_harga AS total_tagihan,
        0.00 AS total_dibayar,
        po.total_harga AS sisa_utang,
        IF(po.total_harga <= 0, 'LUNAS', 'BELUM_LUNAS') AS status,
        CONCAT('Otomatis dari PO: ', po.no_po) AS keterangan
      FROM purchase_orders po
      WHERE NOT EXISTS (
        SELECT 1 FROM accounts_payable ap WHERE ap.po_id = po.id
      );
    `);

    // Sync SO -> accounts_receivable
    await pool.query(`
      INSERT INTO accounts_receivable (no_tagihan, so_id, customer_id, tanggal, jatuh_tempo, total_tagihan, total_dibayar, sisa_piutang, status, keterangan)
      SELECT 
        CONCAT('AR-', so.no_so) AS no_tagihan,
        so.id AS so_id,
        so.customer_id,
        so.tanggal_so AS tanggal,
        COALESCE(so.jatuh_tempo, DATE_ADD(so.tanggal_so, INTERVAL 30 DAY)) AS jatuh_tempo,
        so.total_harga AS total_tagihan,
        0.00 AS total_dibayar,
        so.total_harga AS sisa_piutang,
        IF(so.total_harga <= 0, 'LUNAS', 'BELUM_LUNAS') AS status,
        CONCAT('Otomatis dari SO: ', so.no_so) AS keterangan
      FROM sales_orders so
      WHERE NOT EXISTS (
        SELECT 1 FROM accounts_receivable ar WHERE ar.so_id = so.id
      );
    `);

    console.log('   ✓ Accounts payable & receivable synced.');
  } catch (err) {
    console.warn('   [NOTICE] Utang & Piutang sync message:', err.message);
  }
}

main();

