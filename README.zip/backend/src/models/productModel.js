const pool = require('../config/db');

// Jalankan query ke pool, atau ke koneksi transaksi `conn` jika disediakan
const exec = (sql, params, conn) => (conn || pool).query(sql, params);

const findAll = async (tenantId = null, search = null, warehouseId = null) => {
  const keyword = search ? `%${search}%` : null;
  const [rows] = await exec(
    `SELECT p.id, p.kode_produk, p.nama_produk, p.satuan, p.satuan_besar, p.isi_per_kemasan, p.barcode_kemasan, p.harga, p.rack_id, p.metode_stok, p.tenant_id, p.created_at,
            r.kode_rak,
            t.nama_perusahaan, t.kode_tenant,
            (SELECT COALESCE(SUM(l.stok_qty), 0) FROM product_lots l 
             WHERE l.kode_produk = p.kode_produk 
               AND (? IS NULL OR l.tenant_id = ?)
               AND (? IS NULL OR l.warehouse_id = ?)) AS total_stok,
            (SELECT COUNT(*) FROM product_lots l 
             WHERE l.kode_produk = p.kode_produk 
               AND (? IS NULL OR l.tenant_id = ?)
               AND (? IS NULL OR l.warehouse_id = ?)) AS jumlah_lot
     FROM products p
     LEFT JOIN racks r ON r.id = p.rack_id
     LEFT JOIN tenants t ON t.id = p.tenant_id
     WHERE (? IS NULL OR p.tenant_id = ?)
       AND COALESCE(p.is_deleted, 0) = 0
       AND (? IS NULL OR p.kode_produk LIKE ? OR p.nama_produk LIKE ? OR p.barcode_kemasan LIKE ?)
     ORDER BY p.nama_produk ASC`,
    [
      tenantId, tenantId, warehouseId, warehouseId,
      tenantId, tenantId, warehouseId, warehouseId,
      tenantId, tenantId,
      keyword, keyword, keyword, keyword,
    ]
  );
  return rows;
};

const findByKode = async (tenantId = null, kodeProduk, conn = null) => {
  let tId = tenantId;
  let kode = kodeProduk;
  if (typeof tenantId === 'string' && kodeProduk === undefined) {
    kode = tenantId;
    tId = null;
  }

  const [rows] = await exec(
    `SELECT p.id, p.kode_produk, p.nama_produk, p.satuan, p.satuan_besar, p.isi_per_kemasan, p.barcode_kemasan, p.harga, p.rack_id, p.metode_stok, p.tenant_id, p.created_at,
            r.kode_rak,
            t.nama_perusahaan, t.kode_tenant,
            (SELECT COALESCE(SUM(l.stok_qty), 0) FROM product_lots l WHERE l.kode_produk = p.kode_produk AND (? IS NULL OR l.tenant_id = ?)) AS total_stok,
            (SELECT COUNT(*) FROM product_lots l WHERE l.kode_produk = p.kode_produk AND (? IS NULL OR l.tenant_id = ?)) AS jumlah_lot
     FROM products p
     LEFT JOIN racks r ON r.id = p.rack_id
     LEFT JOIN tenants t ON t.id = p.tenant_id
     WHERE (? IS NULL OR p.tenant_id = ?) AND COALESCE(p.is_deleted, 0) = 0 AND (p.kode_produk = ? OR p.barcode_kemasan = ?)
     LIMIT 1`,
    [tId, tId, tId, tId, tId, tId, kode, kode],
    conn
  );
  if (!rows[0]) return null;
  const p = rows[0];
  return {
    ...p,
    metode_stok: (p.metode_stok || 'FIFO').toUpperCase(),
    is_scanned_kemasan: Boolean(p.barcode_kemasan && p.barcode_kemasan.toUpperCase() === String(kode).toUpperCase()),
  };
};

const create = async ({
  tenantId = 1,
  kodeProduk,
  namaProduk,
  satuan,
  satuanBesar = 'BOX',
  isiPerKemasan = 1,
  barcodeKemasan = null,
  harga = 0,
  rackId = null,
  metodeStok = 'FIFO',
}) => {
  const mStok = (metodeStok || 'FIFO').toUpperCase() === 'FEFO' ? 'FEFO' : 'FIFO';
  const [result] = await exec(
    `INSERT INTO products (tenant_id, kode_produk, nama_produk, satuan, satuan_besar, isi_per_kemasan, barcode_kemasan, harga, rack_id, metode_stok)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      tenantId || 1,
      kodeProduk,
      namaProduk,
      satuan,
      satuanBesar || 'BOX',
      Number(isiPerKemasan) || 1,
      barcodeKemasan || null,
      harga,
      rackId,
      mStok,
    ]
  );
  return result.insertId;
};

const update = async (
  tenantId = null,
  kodeProduk,
  {
    namaProduk,
    satuan,
    satuanBesar = 'BOX',
    isiPerKemasan = 1,
    barcodeKemasan = null,
    harga = 0,
    rackId = null,
    metodeStok = null,
    tenantId: newTenantId = null,
  }
) => {
  const mStok = metodeStok ? ((metodeStok || '').toUpperCase() === 'FEFO' ? 'FEFO' : 'FIFO') : null;
  const [result] = await exec(
    `UPDATE products
     SET nama_produk = ?, satuan = ?, satuan_besar = ?, isi_per_kemasan = ?, barcode_kemasan = ?, harga = ?, rack_id = ?, 
         metode_stok = COALESCE(?, metode_stok), tenant_id = COALESCE(?, tenant_id)
     WHERE (? IS NULL OR tenant_id = ?) AND kode_produk = ?`,
    [
      namaProduk,
      satuan,
      satuanBesar || 'BOX',
      Number(isiPerKemasan) || 1,
      barcodeKemasan || null,
      harga,
      rackId,
      mStok,
      newTenantId,
      tenantId,
      tenantId,
      kodeProduk,
    ]
  );
  return result.affectedRows;
};

const remove = async (tenantId = null, kodeProduk) => {
  const [result] = await exec(`UPDATE products SET is_deleted = 1 WHERE (? IS NULL OR tenant_id = ?) AND kode_produk = ?`, [tenantId, tenantId, kodeProduk]);
  return result.affectedRows;
};

// Daftar lot milik satu produk (bisa diurutkan FEFO atau FIFO)
const findLotsByKode = async (tenantId = null, kodeProduk, metodeOverride = null) => {
  let tId = tenantId;
  let kode = kodeProduk;
  if (typeof tenantId === 'string' && kodeProduk === undefined) {
    kode = tenantId;
    tId = null;
  }

  // Cek produk untuk mendapatkan metode_stok
  const [prod] = await exec(`SELECT metode_stok FROM products WHERE (? IS NULL OR tenant_id = ?) AND kode_produk = ? LIMIT 1`, [tId, tId, kode]);
  const activeMethod = (metodeOverride || prod[0]?.metode_stok || 'FIFO').toUpperCase();

  let orderBySql = `ORDER BY pl.tanggal_produksi ASC, pl.created_at ASC, pl.id DESC`;
  if (activeMethod === 'FEFO') {
    orderBySql = `ORDER BY (pl.expired_date IS NULL) ASC, pl.expired_date ASC, pl.tanggal_produksi ASC, pl.id DESC`;
  }

  const [rows] = await exec(
    `SELECT pl.*, w.nama_gudang, w.kode_gudang,
            p.satuan_besar, p.isi_per_kemasan, p.barcode_kemasan, p.metode_stok,
            DATEDIFF(pl.expired_date, CURRENT_DATE) AS days_to_expire
     FROM product_lots pl
     LEFT JOIN products p ON p.kode_produk = pl.kode_produk AND p.tenant_id = pl.tenant_id
     LEFT JOIN warehouses w ON w.id = pl.warehouse_id
     WHERE (? IS NULL OR pl.tenant_id = ?) AND pl.kode_produk = ?
     ${orderBySql}`,
    [tId, tId, kode]
  );
  return rows.map((r, idx) => {
    const days = r.days_to_expire !== undefined && r.days_to_expire !== null ? Number(r.days_to_expire) : null;
    let autoStatus = r.status || 'AVAILABLE';
    if (days !== null) {
      if (days < 0) autoStatus = 'EXPIRED';
      else if (days <= 90 && autoStatus !== 'QUARANTINE') autoStatus = 'EXPIRING_SOON';
    }
    return {
      ...r,
      days_to_expire: days,
      effective_status: autoStatus,
      is_expired: days !== null && days < 0,
      is_expiring_soon: days !== null && days >= 0 && days <= 90,
      metode_digunakan: activeMethod,
      is_recommended: idx === 0 && r.stok_qty > 0 && autoStatus !== 'EXPIRED' && autoStatus !== 'QUARANTINE',
    };
  });
};

// Semua lot (opsional difilter produk), join info produk & rak
const findAllLots = async (tenantId = null, kodeProduk = null) => {
  const [rows] = await exec(
    `SELECT pl.id, pl.tenant_id, pl.kode_produk, pl.nomor_lot, pl.tanggal_produksi, pl.expired_date, pl.shift, pl.stok_qty, pl.status, pl.keterangan,
            DATEDIFF(pl.expired_date, CURRENT_DATE) AS days_to_expire,
            p.nama_produk, p.satuan, p.satuan_besar, p.isi_per_kemasan, p.barcode_kemasan, p.metode_stok, r.kode_rak, w.nama_gudang, w.kode_gudang
     FROM product_lots pl
     JOIN products p ON p.kode_produk = pl.kode_produk AND p.tenant_id = pl.tenant_id
     LEFT JOIN racks r ON r.id = p.rack_id
     LEFT JOIN warehouses w ON w.id = pl.warehouse_id
     WHERE (? IS NULL OR pl.tenant_id = ?) AND (? IS NULL OR pl.kode_produk = ?)
     ORDER BY pl.expired_date ASC, pl.tanggal_produksi ASC`,
    [tenantId, tenantId, kodeProduk, kodeProduk]
  );
  return rows.map((r) => {
    const days = r.days_to_expire !== undefined && r.days_to_expire !== null ? Number(r.days_to_expire) : null;
    let autoStatus = r.status || 'AVAILABLE';
    if (days !== null) {
      if (days < 0) autoStatus = 'EXPIRED';
      else if (days <= 90 && autoStatus !== 'QUARANTINE') autoStatus = 'EXPIRING_SOON';
    }
    return {
      ...r,
      metode_stok: (r.metode_stok || 'FIFO').toUpperCase(),
      days_to_expire: days,
      effective_status: autoStatus,
      is_expired: days !== null && days < 0,
      is_expiring_soon: days !== null && days >= 0 && days <= 90,
    };
  });
};

const findLotByNomor = async (tenantId = null, nomorLot, conn = null) => {
  let tId = tenantId;
  let nomor = nomorLot;
  if (typeof tenantId === 'string' && nomorLot === undefined) {
    nomor = tenantId;
    tId = null;
  }

  const [rows] = await exec(
    `SELECT pl.id, pl.tenant_id, pl.kode_produk, pl.nomor_lot, pl.tanggal_produksi, pl.expired_date, pl.shift,
            pl.warehouse_id, pl.stok_qty, pl.status, pl.keterangan,
            DATEDIFF(pl.expired_date, CURRENT_DATE) AS days_to_expire,
            w.nama_gudang, w.kode_gudang,
            p.nama_produk, p.satuan, p.satuan_besar, p.isi_per_kemasan, p.barcode_kemasan, p.metode_stok, p.rack_id, r.kode_rak
     FROM product_lots pl
     LEFT JOIN products p ON p.kode_produk = pl.kode_produk AND p.tenant_id = pl.tenant_id
     LEFT JOIN warehouses w ON w.id = pl.warehouse_id
     LEFT JOIN racks r ON r.id = p.rack_id
     WHERE (? IS NULL OR pl.tenant_id = ?) AND pl.nomor_lot = ?
     LIMIT 1`,
    [tId, tId, nomor],
    conn
  );
  if (!rows[0]) return null;
  const r = rows[0];
  const days = r.days_to_expire !== undefined && r.days_to_expire !== null ? Number(r.days_to_expire) : null;
  let autoStatus = r.status || 'AVAILABLE';
  if (days !== null) {
    if (days < 0) autoStatus = 'EXPIRED';
    else if (days <= 90 && autoStatus !== 'QUARANTINE') autoStatus = 'EXPIRING_SOON';
  }
  return {
    ...r,
    metode_stok: (r.metode_stok || 'FIFO').toUpperCase(),
    days_to_expire: days,
    effective_status: autoStatus,
    is_expired: days !== null && days < 0,
    is_expiring_soon: days !== null && days >= 0 && days <= 90,
  };
};

// Kunci baris lot (FOR UPDATE) agar aman terhadap update bersamaan
const lockLot = async (nomorLot, conn) => {
  const [rows] = await exec(
    `SELECT * FROM product_lots WHERE nomor_lot = ? LIMIT 1 FOR UPDATE`,
    [nomorLot],
    conn
  );
  return rows[0] || null;
};

const insertLot = async (
  {
    tenantId = 1,
    kodeProduk,
    nomorLot,
    tanggalProduksi,
    expiredDate = null,
    shift = 1,
    warehouseId = 1,
    stokQty,
    status = 'AVAILABLE',
    keterangan = null,
  },
  conn
) => {
  const exp = expiredDate || new Date(new Date(tanggalProduksi).setFullYear(new Date(tanggalProduksi).getFullYear() + 2)).toISOString().split('T')[0];

  const [result] = await exec(
    `INSERT INTO product_lots
       (tenant_id, kode_produk, nomor_lot, tanggal_produksi, expired_date, shift, warehouse_id, stok_qty, status, keterangan)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [tenantId || 1, kodeProduk, nomorLot, tanggalProduksi, exp, shift, warehouseId || 1, stokQty, status, keterangan],
    conn
  );
  return result.insertId;
};

const increaseStock = async (nomorLot, qty, conn) => {
  const [result] = await exec(
    `UPDATE product_lots SET stok_qty = stok_qty + ? WHERE nomor_lot = ?`,
    [qty, nomorLot],
    conn
  );
  return result.affectedRows;
};

const decreaseStock = async (nomorLot, qty, conn) => {
  const [result] = await exec(
    `UPDATE product_lots SET stok_qty = stok_qty - ?
     WHERE nomor_lot = ? AND stok_qty >= ?`,
    [qty, nomorLot, qty],
    conn
  );
  return result.affectedRows;
};

module.exports = {
  findAll,
  findByKode,
  create,
  update,
  remove,
  findLotsByKode,
  findAllLots,
  findLotByNomor,
  lockLot,
  insertLot,
  increaseStock,
  decreaseStock,
};
