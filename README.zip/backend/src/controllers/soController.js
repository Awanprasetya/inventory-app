const pool = require('../config/db');
const soModel = require('../models/soModel');
const customerModel = require('../models/customerModel');
const productModel = require('../models/productModel');
const receivableModel = require('../models/receivableModel');
const accountingModel = require('../models/accountingModel');
const { asyncHandler, ApiError } = require('../middleware/errorHandler');
const { getTenantId, getTargetTenantId } = require('../utils/tenantHelper');

const generateNoSo = () => {
  const date = new Date();
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `SO/${yyyy}/${mm}/${rand}`;
};

const calculateDueDate = (dateStr, days) => {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + Number(days || 0));
  return d.toISOString().split('T')[0];
};

const getAll = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const status = req.query.status || null;
  const search = req.query.search || '';
  const data = await soModel.findAll(tenantId, status, search);
  res.json({ success: true, data });
});

const getById = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const so = await soModel.findById(tenantId, id);
  if (!so) throw new ApiError(404, 'Sales Order tidak ditemukan');
  const details = await soModel.findDetailsBySoId(id);
  let arDetails = null;
  if (so.ar_id) {
    const payments = await receivableModel.findPaymentsByReceivableId(so.ar_id);
    arDetails = { payments };
  }
  res.json({ success: true, data: { ...so, details, arDetails } });
});

const create = asyncHandler(async (req, res) => {
  const userTenantId = getTargetTenantId(req);
  const customerId = req.body.customer_id ? Number(req.body.customer_id) : null;
  const noSo = (req.body.no_so || generateNoSo()).trim();
  const tanggalSo = req.body.tanggal_so || new Date().toISOString().split('T')[0];
  const terminHari = req.body.termin_hari !== undefined ? Math.max(0, Number(req.body.termin_hari)) : 30;
  const jatuhTempo = req.body.jatuh_tempo || calculateDueDate(tanggalSo, terminHari);
  const keterangan = (req.body.keterangan || '').trim() || null;
  const items = Array.isArray(req.body.items) ? req.body.items : [];

  const diskonPersen = Math.max(0, Number(req.body.diskon_persen) || 0);
  const pajakPersen = Math.max(0, Number(req.body.pajak_persen) || 0);

  if (!noSo) throw new ApiError(400, 'Nomor SO wajib diisi');
  if (items.length === 0) throw new ApiError(400, 'Minimal 1 detail produk pesanan dalam SO');

  if (customerId) {
    const customer = await customerModel.findById(customerId, userTenantId);
    if (!customer) throw new ApiError(404, 'Customer tidak ditemukan');
  }

  const existing = await soModel.findByNoSo(userTenantId, noSo);
  if (existing) throw new ApiError(409, `Nomor SO "${noSo}" sudah ada`);

  const validatedItems = [];
  let calculatedSubtotal = 0;

  for (const item of items) {
    const kodeProduk = (item.kode_produk || '').trim();
    const qtyPesanan = Number(item.qty_pesanan);
    if (!kodeProduk || !Number.isInteger(qtyPesanan) || qtyPesanan <= 0) {
      throw new ApiError(400, `Item produk ${kodeProduk} atau Qty Pesanan ${qtyPesanan} tidak valid`);
    }
    const product = await productModel.findByKode(userTenantId, kodeProduk);
    if (!product) throw new ApiError(404, `Produk "${kodeProduk}" tidak ditemukan`);

    const hargaSatuan =
      item.harga_satuan !== undefined && item.harga_satuan !== ''
        ? Math.max(0, Number(item.harga_satuan))
        : Math.max(0, Number(product.harga || 0));

    const itemDiskon = Math.max(0, Number(item.diskon) || 0);
    const itemSubtotal = Math.max(0, qtyPesanan * hargaSatuan - itemDiskon);
    calculatedSubtotal += itemSubtotal;

    validatedItems.push({
      kodeProduk,
      qtyPesanan,
      hargaSatuan,
      diskon: itemDiskon,
      subtotal: itemSubtotal,
    });
  }

  const subtotal = calculatedSubtotal;
  let diskonNominal =
    req.body.diskon_nominal !== undefined && req.body.diskon_nominal !== ''
      ? Math.max(0, Number(req.body.diskon_nominal))
      : Math.round((subtotal * diskonPersen) / 100);

  if (diskonNominal > subtotal) diskonNominal = subtotal;

  const dpp = Math.max(0, subtotal - diskonNominal);
  const pajakNominal =
    req.body.pajak_nominal !== undefined && req.body.pajak_nominal !== ''
      ? Math.max(0, Number(req.body.pajak_nominal))
      : Math.round((dpp * pajakPersen) / 100);

  const totalHarga = dpp + pajakNominal;

  const conn = await pool.getConnection();
  await conn.beginTransaction();
  try {
    const soId = await soModel.create(
      {
        tenantId: userTenantId,
        noSo,
        customerId,
        tanggalSo,
        terminHari,
        jatuhTempo,
        status: 'OPEN',
        keterangan,
        subtotal,
        diskonPersen,
        diskonNominal,
        pajakPersen,
        pajakNominal,
        totalHarga,
      },
      conn
    );

    for (const item of validatedItems) {
      await soModel.createDetail(
        {
          tenantId: userTenantId,
          soId,
          kodeProduk: item.kodeProduk,
          qtyPesanan: item.qtyPesanan,
          hargaSatuan: item.hargaSatuan,
          diskon: item.diskon,
          subtotal: item.subtotal,
          qtyTerkirim: 0,
        },
        conn
      );
    }

    // Integrasi otomatis Piutang Usaha (Accounts Receivable)
    await receivableModel.create(
      {
        tenantId: userTenantId,
        noTagihan: `AR-${noSo}`,
        soId,
        customerId,
        tanggal: tanggalSo,
        jatuhTempo,
        totalTagihan: totalHarga,
        keterangan: `Faktur Piutang otomatis dari SO ${noSo}`,
      },
      conn
    );

    // Integrasi otomatis Jurnal Akuntansi ERP
    const accAr = await accountingModel.getAccountIdByKode('1-1010', conn);
    const accSales = await accountingModel.getAccountIdByKode('4-1001', conn);
    const accPpnOut = await accountingModel.getAccountIdByKode('2-1002', conn);

    if (accAr && accSales && totalHarga > 0) {
      const journalLines = [
        { accountId: accAr.id, debit: totalHarga, credit: 0, keterangan: `Piutang Dagang ${noSo}` },
        { accountId: accSales.id, debit: 0, credit: dpp, keterangan: `Pendapatan Penjualan ${noSo}` },
      ];
      if (pajakNominal > 0 && accPpnOut) {
        journalLines.push({ accountId: accPpnOut.id, debit: 0, credit: pajakNominal, keterangan: `PPN Keluaran ${noSo}` });
      }

      await accountingModel.postJournal(
        {
          tenantId: userTenantId,
          tanggal: tanggalSo,
          tipeReferensi: 'SO',
          referensiId: soId,
          noReferensi: noSo,
          keterangan: `Faktur Penjualan ${noSo}`,
          createdBy: req.user ? req.user.id : null,
          lines: journalLines,
        },
        conn
      );
    }

    await conn.commit();
    const data = await soModel.findById(userTenantId, soId);
    const details = await soModel.findDetailsBySoId(soId);
    res.status(201).json({
      success: true,
      message: 'Sales Order & Tagihan Piutang berhasil dibuat',
      data: { ...data, details },
    });
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
});

const updateStatus = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const status = (req.body.status || '').trim().toUpperCase();
  const validStatuses = ['OPEN', 'PROCESSING', 'CLOSED', 'CANCELLED'];

  if (!validStatuses.includes(status)) {
    throw new ApiError(400, `Status tidak valid. Pilihan: ${validStatuses.join(', ')}`);
  }

  const so = await soModel.findById(tenantId, id);
  if (!so) throw new ApiError(404, 'Sales Order tidak ditemukan');

  await soModel.updateStatus(id, status);
  const data = await soModel.findById(tenantId, id);
  res.json({ success: true, message: `Status SO diubah menjadi ${status}`, data });
});

const remove = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const so = await soModel.findById(tenantId, id);
  if (!so) throw new ApiError(404, 'Sales Order tidak ditemukan');

  const ar = await receivableModel.findBySoId(id);
  if (ar) {
    const payments = await receivableModel.findPaymentsByReceivableId(ar.id);
    if (payments.length > 0) {
      throw new ApiError(
        400,
        'Sales Order tidak dapat dihapus karena sudah memiliki riwayat pembayaran piutang. Hapus riwayat pembayaran terlebih dahulu.'
      );
    }
    await receivableModel.remove(ar.id);
  }

  await soModel.remove(id);
  res.json({ success: true, message: 'Sales Order & Tagihan Piutang berhasil dihapus' });
});

module.exports = {
  getAll,
  getById,
  create,
  updateStatus,
  remove,
};
