const pool = require('../config/db');
const doModel = require('../models/doModel');
const soModel = require('../models/soModel');
const customerModel = require('../models/customerModel');
const productModel = require('../models/productModel');
const { asyncHandler, ApiError } = require('../middleware/errorHandler');
const { getTenantId, getTargetTenantId } = require('../utils/tenantHelper');

const generateNoDo = () => {
  const date = new Date();
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `DO/${yyyy}/${mm}/${rand}`;
};

const getAll = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const status = req.query.status || null;
  const search = req.query.search || '';
  const data = await doModel.findAll(tenantId, status, search);
  res.json({ success: true, data });
});

const getById = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const doData = await doModel.findById(tenantId, id);
  if (!doData) throw new ApiError(404, 'Delivery Order tidak ditemukan');
  const details = await doModel.findDetailsByDoId(id);
  res.json({ success: true, data: { ...doData, details } });
});

const create = asyncHandler(async (req, res) => {
  const userTenantId = getTargetTenantId(req);
  const soId = req.body.so_id ? Number(req.body.so_id) : null;
  let customerId = req.body.customer_id ? Number(req.body.customer_id) : null;
  const noDo = (req.body.no_do || generateNoDo()).trim();
  const tanggalDo = req.body.tanggal_do || new Date().toISOString().split('T')[0];
  const status = (req.body.status || 'DRAFT').toUpperCase();
  const items = Array.isArray(req.body.items) ? req.body.items : [];

  if (!noDo) throw new ApiError(400, 'Nomor DO wajib diisi');
  if (items.length === 0) throw new ApiError(400, 'Minimal 1 lot pengiriman dalam DO');

  if (soId) {
    const so = await soModel.findById(userTenantId, soId);
    if (!so) throw new ApiError(404, 'Sales Order tidak ditemukan');
    if (!customerId && so.customer_id) customerId = so.customer_id;
  }

  if (customerId) {
    const customer = await customerModel.findById(customerId, userTenantId);
    if (!customer) throw new ApiError(404, 'Customer tidak ditemukan');
  }

  const existing = await doModel.findByNoDo(userTenantId, noDo);
  if (existing) throw new ApiError(409, `Nomor DO "${noDo}" sudah ada`);

  const conn = await pool.getConnection();
  await conn.beginTransaction();
  try {
    const doId = await doModel.create(
      { tenantId: userTenantId, noDo, soId, customerId, tanggalDo, status },
      conn
    );

    for (const item of items) {
      const nomorLot = (item.nomor_lot || '').trim();
      const qtyKirim = Number(item.qty_kirim);
      if (!nomorLot || !Number.isInteger(qtyKirim) || qtyKirim <= 0) {
        throw new ApiError(400, `Nomor Lot ${nomorLot} atau Qty Kirim ${qtyKirim} tidak valid`);
      }
      const lot = await productModel.findLotByNomor(userTenantId, nomorLot);
      if (!lot) throw new ApiError(404, `Lot "${nomorLot}" tidak ditemukan`);

      await doModel.createDetail({ tenantId: userTenantId, doId, nomorLot, qtyKirim }, conn);
    }

    if (soId && (status === 'SHIPPED' || status === 'DELIVERED')) {
      const doDetails = await doModel.findDetailsByDoId(doId);
      const soDetails = await soModel.findDetailsBySoId(soId);

      for (const dod of doDetails) {
        const matchingSoDetail = soDetails.find((sod) => sod.kode_produk === dod.kode_produk);
        if (matchingSoDetail) {
          await soModel.updateDetailQtyTerkirim(matchingSoDetail.id, dod.qty_kirim, conn);
        }
      }

      const updatedSoDetails = await soModel.findDetailsBySoId(soId);
      const allFulfilled = updatedSoDetails.every((d) => d.qty_terkirim >= d.qty_pesanan);
      await soModel.updateStatus(soId, allFulfilled ? 'CLOSED' : 'PROCESSING', conn);
    }

    await conn.commit();
    const data = await doModel.findById(userTenantId, doId);
    const details = await doModel.findDetailsByDoId(doId);
    res.status(201).json({
      success: true,
      message: 'Delivery Order berhasil dibuat',
      data: { ...data, details },
    });
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
});

const updateStatus = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const status = (req.body.status || '').trim().toUpperCase();
  const validStatuses = ['DRAFT', 'SHIPPED', 'DELIVERED'];

  if (!validStatuses.includes(status)) {
    throw new ApiError(400, `Status tidak valid. Pilihan: ${validStatuses.join(', ')}`);
  }

  const doData = await doModel.findById(tenantId, id);
  if (!doData) throw new ApiError(404, 'Delivery Order tidak ditemukan');

  const oldStatus = doData.status;

  const conn = await pool.getConnection();
  await conn.beginTransaction();
  try {
    await doModel.updateStatus(id, status, conn);

    if (doData.so_id && oldStatus === 'DRAFT' && (status === 'SHIPPED' || status === 'DELIVERED')) {
      const doDetails = await doModel.findDetailsByDoId(id);
      const soDetails = await soModel.findDetailsBySoId(doData.so_id);

      for (const dod of doDetails) {
        const matchingSoDetail = soDetails.find((sod) => sod.kode_produk === dod.kode_produk);
        if (matchingSoDetail) {
          await soModel.updateDetailQtyTerkirim(matchingSoDetail.id, dod.qty_kirim, conn);
        }
      }

      const updatedSoDetails = await soModel.findDetailsBySoId(doData.so_id);
      const allFulfilled = updatedSoDetails.every((d) => d.qty_terkirim >= d.qty_pesanan);
      await soModel.updateStatus(doData.so_id, allFulfilled ? 'CLOSED' : 'PROCESSING', conn);
    }

    await conn.commit();
    const data = await doModel.findById(tenantId, id);
    res.json({ success: true, message: `Status DO diubah menjadi ${status}`, data });
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
});

const remove = asyncHandler(async (req, res) => {
  const tenantId = getTenantId(req);
  const id = Number(req.params.id);
  const doData = await doModel.findById(tenantId, id);
  if (!doData) throw new ApiError(404, 'Delivery Order tidak ditemukan');

  await doModel.remove(id);
  res.json({ success: true, message: 'Delivery Order berhasil dihapus' });
});

module.exports = {
  getAll,
  getById,
  create,
  updateStatus,
  remove,
};
