import { useEffect, useState } from 'react';
import {
  Building2,
  Plus,
  Search,
  Calendar,
  AlertCircle,
  Loader2,
  RefreshCw,
  ArrowRightLeft,
  MapPin,
  User,
  Phone,
  Package,
  CheckCircle2,
  Trash2,
  Edit2,
  FileSpreadsheet,
} from 'lucide-react';
import api, { getErrorMessage, formatDate } from '../services/api.js';
import Modal from '../components/Modal.jsx';
import Pagination, { paginate } from '../components/Pagination.jsx';
import SearchableSelect from '../components/SearchableSelect.jsx';
import { confirmDelete, toastSuccess, alertError } from '../utils/alert.js';
import { exportToExcel } from '../utils/exportHelper.js';

const PAGE_SIZE = 10;

const WAREHOUSE_TYPES = [
  { value: 'UTAMA', label: 'Gudang Utama & Logistik' },
  { value: 'FARMASI', label: 'Gudang Farmasi & Obat-obatan' },
  { value: 'KARANTINA', label: 'Gudang Karantina & Retur' },
  { value: 'CABANG', label: 'Gudang Cabang / Mitra RS' },
];

export default function Warehouses() {
  const [activeTab, setActiveTab] = useState('MASTER'); // 'MASTER' | 'TRANSFERS'
  const [warehouses, setWarehouses] = useState([]);
  const [transfers, setTransfers] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Modal Master Gudang
  const [whModalOpen, setWhModalOpen] = useState(false);
  const [editingWh, setEditingWh] = useState(null);
  const [whForm, setWhForm] = useState({
    kode_gudang: '',
    nama_gudang: '',
    tipe_gudang: 'UTAMA',
    alamat: '',
    penanggung_jawab: '',
    telepon: '',
  });

  // Modal Transfer Stok
  const [trfModalOpen, setTrfModalOpen] = useState(false);
  const [trfForm, setTrfForm] = useState({
    from_warehouse_id: '',
    to_warehouse_id: '',
    tanggal: new Date().toISOString().split('T')[0],
    catatan: '',
    items: [],
  });

  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  const loadData = async () => {
    setLoading(true);
    setError('');
    try {
      const [whRes, trfRes, prodRes] = await Promise.all([
        api.get('/warehouses'),
        api.get('/warehouses/transfers'),
        api.get('/products'),
      ]);

      if (whRes.data.success) setWarehouses(whRes.data.data || []);
      if (trfRes.data.success) setTransfers(trfRes.data.data || []);
      if (prodRes.data.success) setProducts(prodRes.data.data || []);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Handlers Master Gudang
  const handleOpenAddWh = () => {
    setEditingWh(null);
    setWhForm({
      kode_gudang: `GDG-0${warehouses.length + 1}`,
      nama_gudang: '',
      tipe_gudang: 'UTAMA',
      alamat: '',
      penanggung_jawab: '',
      telepon: '',
    });
    setWhModalOpen(true);
  };

  const handleOpenEditWh = (wh) => {
    setEditingWh(wh);
    setWhForm({
      kode_gudang: wh.kode_gudang,
      nama_gudang: wh.nama_gudang,
      tipe_gudang: wh.tipe_gudang,
      alamat: wh.alamat || '',
      penanggung_jawab: wh.penanggung_jawab || '',
      telepon: wh.telepon || '',
    });
    setWhModalOpen(true);
  };

  const handleSaveWh = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editingWh) {
        const res = await api.put(`/warehouses/${editingWh.id}`, whForm);
        toastSuccess('Berhasil!', res.data.message);
      } else {
        const res = await api.post('/warehouses', whForm);
        toastSuccess('Berhasil!', res.data.message);
      }
      setWhModalOpen(false);
      loadData();
    } catch (err) {
      alertError('Gagal Menyimpan Gudang', getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteWh = async (wh) => {
    const isConfirmed = await confirmDelete(
      `Hapus Gudang ${wh.nama_gudang}?`,
      'Gudang hanya bisa dihapus jika tidak memiliki stok fisik aktif.'
    );
    if (!isConfirmed) return;

    try {
      const res = await api.delete(`/warehouses/${wh.id}`);
      toastSuccess('Dihapus!', res.data.message);
      loadData();
    } catch (err) {
      alertError('Gagal Menghapus', getErrorMessage(err));
    }
  };

  // Handlers Transfer Stok
  const handleOpenAddTrf = () => {
    const fromWh = warehouses[0]?.id ? String(warehouses[0].id) : '';
    const toWh = warehouses[1]?.id ? String(warehouses[1].id) : '';
    const defaultProd = products[0]?.id ? String(products[0].id) : '';

    setTrfForm({
      from_warehouse_id: fromWh,
      to_warehouse_id: toWh,
      tanggal: new Date().toISOString().split('T')[0],
      catatan: '',
      items: defaultProd ? [{ product_id: defaultProd, qty: 10, catatan: '' }] : [],
    });
    setTrfModalOpen(true);
  };

  const handleAddTrfItem = () => {
    const defaultProd = products[0]?.id ? String(products[0].id) : '';
    setTrfForm((prev) => ({
      ...prev,
      items: [...prev.items, { product_id: defaultProd, qty: 10, catatan: '' }],
    }));
  };

  const handleRemoveTrfItem = (index) => {
    setTrfForm((prev) => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index),
    }));
  };

  const handleTrfItemChange = (index, field, value) => {
    setTrfForm((prev) => {
      const updated = [...prev.items];
      updated[index] = { ...updated[index], [field]: value };
      return { ...prev, items: updated };
    });
  };

  const handleSaveTransfer = async (e) => {
    e.preventDefault();
    if (!trfForm.from_warehouse_id || !trfForm.to_warehouse_id) {
      alertError('Peringatan', 'Pilih gudang asal dan gudang tujuan!');
      return;
    }
    if (trfForm.from_warehouse_id === trfForm.to_warehouse_id) {
      alertError('Peringatan', 'Gudang asal dan tujuan tidak boleh sama!');
      return;
    }
    if (trfForm.items.length === 0) {
      alertError('Peringatan', 'Pilih minimal 1 barang untuk ditransfer!');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        ...trfForm,
        from_warehouse_id: Number(trfForm.from_warehouse_id),
        to_warehouse_id: Number(trfForm.to_warehouse_id),
        items: trfForm.items.map((it) => ({
          product_id: Number(it.product_id),
          qty: Number(it.qty),
          catatan: it.catatan,
        })),
      };

      const res = await api.post('/warehouses/transfers', payload);
      toastSuccess('Transfer Sukses!', res.data.message);
      setTrfModalOpen(false);
      loadData();
    } catch (err) {
      alertError('Gagal Memproses Transfer', getErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const { pageItems: paginatedTransfers, totalPages, safePage } = paginate(
    transfers,
    page,
    pageSize
  );

  const handleExportExcel = () => {
    if (activeTab === 'MASTER') {
      const headers = [
        'Kode Gudang',
        'Nama Gudang',
        'Tipe Gudang',
        'Alamat',
        'Penanggung Jawab',
        'Telepon',
        'Tanggal Terdaftar',
      ];
      const data = warehouses.map((wh) => {
        const typeObj = WAREHOUSE_TYPES.find((t) => t.value === wh.tipe_gudang);
        return [
          wh.kode_gudang || '',
          wh.nama_gudang || '',
          typeObj ? typeObj.label : wh.tipe_gudang,
          wh.alamat || '-',
          wh.penanggung_jawab || '-',
          wh.telepon || '-',
          formatDate(wh.created_at || wh.createdAt),
        ];
      });
      exportToExcel('Master_Daftar_Gudang', headers, data);
    } else {
      const headers = [
        'No. Transfer',
        'Tanggal',
        'Gudang Asal',
        'Gudang Tujuan',
        'Jumlah Item Barang',
        'Catatan / Referensi',
      ];
      const data = transfers.map((trf) => [
        trf.no_transfer || '',
        formatDate(trf.tanggal),
        trf.FromWarehouse ? `${trf.FromWarehouse.kode_gudang} - ${trf.FromWarehouse.nama_gudang}` : '',
        trf.ToWarehouse ? `${trf.ToWarehouse.kode_gudang} - ${trf.ToWarehouse.nama_gudang}` : '',
        trf.items?.length || 0,
        trf.catatan || '-',
      ]);
      exportToExcel('Riwayat_Transfer_Stok_Antar_Gudang', headers, data);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-800 flex items-center gap-2">
            <Building2 className="h-7 w-7 text-blue-600" />
            Manajemen Multi-Gudang & Transfer Stok
          </h1>
          <p className="text-sm text-slate-500">
            Pengelolaan lokasi gudang medis (Pusat, Farmasi, Karantina, Cabang) dan pergerakan mutasi stok antar lokasi.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50"
            title="Export ke Excel"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-600" />
            Export Excel
          </button>
          <button
            onClick={loadData}
            disabled={loading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin text-blue-600' : ''}`} />
            Segarkan
          </button>
          {activeTab === 'MASTER' ? (
            <button
              onClick={handleOpenAddWh}
              className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-700 transition"
            >
              <Plus className="h-4 w-4" />
              Tambah Gudang Baru
            </button>
          ) : (
            <button
              onClick={handleOpenAddTrf}
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700 transition"
            >
              <ArrowRightLeft className="h-4 w-4" />
              Buat Transfer Stok
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('MASTER')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-semibold transition ${
            activeTab === 'MASTER'
              ? 'border-blue-600 text-blue-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Building2 className="h-4 w-4" />
          Master Gudang ({warehouses.length})
        </button>
        <button
          onClick={() => setActiveTab('TRANSFERS')}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-semibold transition ${
            activeTab === 'TRANSFERS'
              ? 'border-indigo-600 text-indigo-600'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ArrowRightLeft className="h-4 w-4" />
          Transfer Antar Gudang ({transfers.length})
        </button>
      </div>

      {loading ? (
        <div className="flex h-64 items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
          <span className="ml-2 text-slate-600 font-medium">Memuat data gudang & mutasi...</span>
        </div>
      ) : error ? (
        <div className="p-8 text-center text-red-600 flex flex-col items-center">
          <AlertCircle className="h-10 w-10 mb-2" />
          <p className="font-semibold">{error}</p>
        </div>
      ) : activeTab === 'MASTER' ? (
        /* Tab 1: Master Gudang */
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-4">
          {warehouses.map((wh) => (
            <div
              key={wh.id}
              className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 shadow-sm hover:border-blue-300 transition"
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                    {wh.kode_gudang}
                  </span>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${
                      wh.tipe_gudang === 'KARANTINA'
                        ? 'bg-purple-100 text-purple-800'
                        : wh.tipe_gudang === 'FARMASI'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-100 text-slate-700'
                    }`}
                  >
                    {wh.tipe_gudang}
                  </span>
                </div>

                <h3 className="mt-2 text-base font-bold text-slate-900">{wh.nama_gudang}</h3>

                {wh.alamat && (
                  <p className="mt-1 flex items-start gap-1 text-xs text-slate-500">
                    <MapPin className="h-3.5 w-3.5 shrink-0 text-slate-400 mt-0.5" />
                    <span>{wh.alamat}</span>
                  </p>
                )}

                <div className="mt-4 space-y-1.5 border-t border-slate-100 pt-3 text-xs text-slate-600">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 flex items-center gap-1">
                      <User className="h-3 w-3" /> PIC:
                    </span>
                    <span className="font-medium text-slate-800">{wh.penanggung_jawab || '-'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 flex items-center gap-1">
                      <Phone className="h-3 w-3" /> Telepon:
                    </span>
                    <span>{wh.telepon || '-'}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 flex items-center gap-1">
                      <Package className="h-3 w-3" /> Total Stok Fisik:
                    </span>
                    <span className="font-bold text-blue-700">
                      {wh.total_stok?.toLocaleString('id-ID')} unit
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-5 flex items-center justify-end gap-2 border-t border-slate-100 pt-3">
                <button
                  onClick={() => handleOpenEditWh(wh)}
                  className="rounded p-1 text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition"
                  title="Edit Gudang"
                >
                  <Edit2 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => handleDeleteWh(wh)}
                  className="rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-600 transition"
                  title="Hapus Gudang"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Tab 2: Transfer Stok Antar Gudang */
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
          {transfers.length === 0 ? (
            <div className="p-12 text-center text-slate-500">
              <ArrowRightLeft className="mx-auto h-12 w-12 text-slate-300 mb-3" />
              <p className="text-base font-semibold text-slate-700">Belum Ada Mutasi Transfer Gudang</p>
              <p className="text-sm mt-1">Pindahkan barang antar cabang atau ke gudang karantina dengan aman.</p>
              <button
                onClick={handleOpenAddTrf}
                className="mt-4 inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-700"
              >
                <ArrowRightLeft className="h-4 w-4" />
                Buat Transfer Pertama
              </button>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-600">
                  <thead className="border-b border-slate-200 bg-slate-50 text-xs font-semibold uppercase text-slate-700">
                    <tr>
                      <th className="px-4 py-3">No Transfer & Tgl</th>
                      <th className="px-4 py-3">Gudang Asal</th>
                      <th className="px-4 py-3">Gudang Tujuan</th>
                      <th className="px-4 py-3">Barang Ditransfer</th>
                      <th className="px-4 py-3">Catatan</th>
                      <th className="px-4 py-3">Petugas</th>
                      <th className="px-4 py-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {paginatedTransfers.map((trf) => (
                      <tr key={trf.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="px-4 py-3.5">
                          <div className="font-semibold text-slate-900">{trf.no_transfer}</div>
                          <div className="flex items-center gap-1 text-xs text-slate-500 mt-0.5">
                            <Calendar className="h-3 w-3 text-slate-400" />
                            <span>{formatDate(trf.tanggal)}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="font-medium text-slate-800">{trf.from_warehouse_nama}</div>
                          <div className="text-xs text-slate-400 font-mono">{trf.from_warehouse_kode}</div>
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="font-medium text-slate-800">{trf.to_warehouse_nama}</div>
                          <div className="text-xs text-slate-400 font-mono">{trf.to_warehouse_kode}</div>
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="space-y-1">
                            {trf.items?.map((it, idx) => (
                              <div key={idx} className="text-xs text-slate-700">
                                <strong>{it.nama_produk}</strong> ({it.qty} {it.satuan})
                              </div>
                            ))}
                          </div>
                        </td>
                        <td className="px-4 py-3.5 text-xs text-slate-500">
                          {trf.catatan || '-'}
                        </td>
                        <td className="px-4 py-3.5 text-xs text-slate-800 font-medium">
                          {trf.created_by_name || 'Admin'}
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2.5 py-0.5 text-xs font-semibold text-emerald-700 border border-emerald-200">
                            <CheckCircle2 className="h-3 w-3" /> SELESAI
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="border-t border-slate-200 px-4 py-3">
                <Pagination
                  page={safePage}
                  totalPages={totalPages}
                  onPage={setPage}
                  totalItems={transfers.length}
                  pageSize={pageSize}
                  onPageSize={(newSize) => {
                    setPageSize(newSize);
                    setPage(1);
                  }}
                  label="mutasi transfer"
                />
              </div>
            </>
          )}
        </div>
      )}

      {/* Modal Tambah / Edit Gudang */}
      <Modal
        isOpen={whModalOpen}
        onClose={() => setWhModalOpen(false)}
        title={editingWh ? 'Edit Informasi Gudang' : 'Tambah Gudang Penyimpanan Baru'}
        maxWidth="max-w-md"
      >
        <form onSubmit={handleSaveWh} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
              Kode Gudang <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              disabled={Boolean(editingWh)}
              value={whForm.kode_gudang}
              onChange={(e) => setWhForm({ ...whForm, kode_gudang: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none disabled:bg-slate-100"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
              Nama Gudang <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              value={whForm.nama_gudang}
              onChange={(e) => setWhForm({ ...whForm, nama_gudang: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
              placeholder="cth: Gudang Distribusi Farmasi"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
              Tipe Gudang <span className="text-red-500">*</span>
            </label>
            <SearchableSelect
              value={whForm.tipe_gudang}
              onChange={(e) => setWhForm({ ...whForm, tipe_gudang: e.target.value })}
              options={WAREHOUSE_TYPES}
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
              Alamat Lengkap
            </label>
            <textarea
              rows={2}
              value={whForm.alamat}
              onChange={(e) => setWhForm({ ...whForm, alamat: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
              placeholder="Alamat fasilitas gudang..."
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
                Penanggung Jawab (PIC)
              </label>
              <input
                type="text"
                value={whForm.penanggung_jawab}
                onChange={(e) => setWhForm({ ...whForm, penanggung_jawab: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
                No Telepon
              </label>
              <input
                type="text"
                value={whForm.telepon}
                onChange={(e) => setWhForm({ ...whForm, telepon: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setWhModalOpen(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Simpan Gudang
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Buat Transfer Stok Antar Gudang */}
      <Modal
        isOpen={trfModalOpen}
        onClose={() => setTrfModalOpen(false)}
        title="Formulir Transfer Stok Antar Gudang"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleSaveTransfer} className="space-y-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
                Gudang Asal <span className="text-red-500">*</span>
              </label>
              <SearchableSelect
                value={trfForm.from_warehouse_id}
                onChange={(e) => setTrfForm({ ...trfForm, from_warehouse_id: e.target.value })}
                options={warehouses.map((w) => ({ value: String(w.id), label: `${w.kode_gudang} - ${w.nama_gudang}` }))}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
                Gudang Tujuan <span className="text-red-500">*</span>
              </label>
              <SearchableSelect
                value={trfForm.to_warehouse_id}
                onChange={(e) => setTrfForm({ ...trfForm, to_warehouse_id: e.target.value })}
                options={warehouses.map((w) => ({ value: String(w.id), label: `${w.kode_gudang} - ${w.nama_gudang}` }))}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
                Tanggal Transfer <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                required
                value={trfForm.tanggal}
                onChange={(e) => setTrfForm({ ...trfForm, tanggal: e.target.value })}
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Items to transfer */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                Daftar Barang yang Dipindahkan
              </h4>
              <button
                type="button"
                onClick={handleAddTrfItem}
                className="inline-flex items-center gap-1 rounded bg-indigo-50 px-2.5 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 transition"
              >
                <Plus className="h-3.5 w-3.5" />
                Tambah Barang
              </button>
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
              {trfForm.items.map((item, idx) => (
                <div
                  key={idx}
                  className="grid grid-cols-12 gap-2 items-center rounded-lg border border-slate-200 bg-slate-50 p-2.5"
                >
                  <div className="col-span-7">
                    <label className="block text-[10px] font-semibold text-slate-500 mb-1">
                      Pilih Produk
                    </label>
                    <SearchableSelect
                      value={item.product_id}
                      onChange={(e) => handleTrfItemChange(idx, 'product_id', e.target.value)}
                      options={products.map((p) => ({
                        value: String(p.id),
                        label: `${p.kode_produk} - ${p.nama_produk}`,
                      }))}
                    />
                  </div>

                  <div className="col-span-4">
                    <label className="block text-[10px] font-semibold text-indigo-700 mb-1">
                      Jumlah Transfer (Qty) *
                    </label>
                    <input
                      type="number"
                      min="1"
                      required
                      value={item.qty}
                      onChange={(e) => handleTrfItemChange(idx, 'qty', e.target.value)}
                      className="w-full rounded border border-indigo-400 bg-white px-2 py-1.5 text-xs font-bold text-center focus:outline-none"
                    />
                  </div>

                  <div className="col-span-1 flex justify-center">
                    <button
                      type="button"
                      onClick={() => handleRemoveTrfItem(idx)}
                      disabled={trfForm.items.length <= 1}
                      className="rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-600 disabled:opacity-30"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase text-slate-600 mb-1">
              Catatan / Instruksi Pengiriman
            </label>
            <textarea
              rows={2}
              value={trfForm.catatan}
              onChange={(e) => setTrfForm({ ...trfForm, catatan: e.target.value })}
              className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none"
              placeholder="cth: Distribusi stok ampul ke gudang cabang Surabaya..."
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setTrfModalOpen(false)}
              className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={saving}
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-5 py-2 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-50"
            >
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Eksekusi Transfer Stok
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

