import { useEffect, useState } from 'react';
import {
  ClipboardList,
  Loader2,
  AlertCircle,
  FileSpreadsheet,
  ArrowDownLeft,
  ArrowUpRight,
  RefreshCw,
  Building,
  RotateCcw,
  CheckCircle2,
  Calendar,
  Layers,
} from 'lucide-react';
import api, { getErrorMessage, formatNumber, formatDateTime } from '../services/api.js';
import Pagination, { paginate } from '../components/Pagination.jsx';
import SearchableSelect from '../components/SearchableSelect.jsx';
import { exportToExcel } from '../utils/exportHelper.js';

const MUTATION_BADGES = {
  MASUK: { label: 'Barang Masuk (Inbound)', color: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  KELUAR: { label: 'Barang Keluar (Outbound)', color: 'bg-orange-50 text-orange-700 border-orange-200' },
  ADJUSTMENT_MASUK: { label: 'Stok Opname (+)', color: 'bg-teal-50 text-teal-700 border-teal-200' },
  ADJUSTMENT_KELUAR: { label: 'Stok Opname (-)', color: 'bg-rose-50 text-rose-700 border-rose-200' },
  TRANSFER_MASUK: { label: 'Transfer Masuk', color: 'bg-blue-50 text-blue-700 border-blue-200' },
  TRANSFER_KELUAR: { label: 'Transfer Keluar', color: 'bg-amber-50 text-amber-700 border-amber-200' },
  RETUR_BELI: { label: 'Retur ke Supplier', color: 'bg-purple-50 text-purple-700 border-purple-200' },
  RETUR_JUAL: { label: 'Retur dari Pelanggan', color: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
};

const POSITIVE_TYPES = ['MASUK', 'ADJUSTMENT_MASUK', 'TRANSFER_MASUK', 'RETUR_JUAL'];

export default function StockCard() {
  const [products, setProducts] = useState([]);
  const [warehouses, setWarehouses] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [selectedWarehouse, setSelectedWarehouse] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [report, setReport] = useState(null); // { product, rows, ringkasan }
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  useEffect(() => {
    (async () => {
      try {
        const [prodRes, whRes] = await Promise.all([
          api.get('/products'),
          api.get('/warehouses'),
        ]);
        const pList = prodRes.data.data || [];
        setProducts(pList);
        setWarehouses(whRes.data.data || []);
        if (pList.length > 0) {
          setSelectedProduct(pList[0].kode_produk);
        }
      } catch (err) {
        setError(getErrorMessage(err));
      }
    })();
  }, []);

  const loadReport = async (kodeProduk, tanggalDari, tanggalSampai, whId) => {
    if (!kodeProduk) {
      setReport(null);
      return;
    }
    setLoading(true);
    setError('');
    setPage(1);
    try {
      const { data } = await api.get(`/stock-card/${encodeURIComponent(kodeProduk)}`, {
        params: {
          from: tanggalDari || undefined,
          to: tanggalSampai || undefined,
          warehouse_id: whId || undefined,
        },
      });
      setReport(data.data);
    } catch (err) {
      setReport(null);
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  // Muat otomatis saat produk pertama tersedia atau gudang berubah
  useEffect(() => {
    if (selectedProduct) {
      loadReport(selectedProduct, from, to, selectedWarehouse);
    }
  }, [selectedProduct, selectedWarehouse]);

  const handleFilter = (e) => {
    e.preventDefault();
    loadReport(selectedProduct, from, to, selectedWarehouse);
  };

  const clearFilter = () => {
    setFrom('');
    setTo('');
    setSelectedWarehouse('');
    loadReport(selectedProduct, '', '', '');
  };

  const handleExportExcel = () => {
    if (!report || !report.rows || report.rows.length === 0) {
      alert('Tidak ada mutasi stok yang dapat diexport.');
      return;
    }

    const headers = [
      'Waktu Mutasi',
      'Kode Produk',
      'Nama Produk',
      'Gudang',
      'No. Lot / Batch',
      'Tipe Mutasi',
      'Jumlah Masuk (+)',
      'Jumlah Keluar (-)',
      'Sisa Stok Fisik',
      'Referensi Dokumen',
    ];

    const data = report.rows.map((row) => {
      const isPositive = POSITIVE_TYPES.includes(row.tipe);
      const badgeInfo = MUTATION_BADGES[row.tipe] || { label: row.tipe };
      return [
        formatDateTime(row.tanggal_mutasi),
        report.product?.kode_produk || selectedProduct,
        report.product?.nama_produk || '',
        row.nama_gudang || 'Pusat Logistik',
        row.nomor_lot || '-',
        badgeInfo.label,
        isPositive ? row.qty_perubahan ?? 0 : 0,
        !isPositive ? row.qty_perubahan ?? 0 : 0,
        row.qty_sisa ?? 0,
        row.referensi || '-',
      ];
    });

    const filename = `Kartu_Stok_${report.product?.kode_produk || selectedProduct}`;
    exportToExcel(filename, headers, data);
  };

  return (
    <div className="space-y-6">
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Kartu Stok Realtime & Audit Mutasi</h1>
          <p className="text-sm text-slate-500 mt-1">
            Rekam jejak seluruh mutasi fisik: Masuk (PO), Keluar (DO), Stok Opname, Transfer Antar Gudang, dan Retur.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportExcel}
            className="flex items-center gap-2 px-3.5 py-2 text-sm font-semibold text-slate-700 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 shadow-xs transition"
            title="Export ke Excel"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            Export Excel
          </button>
          <button
            onClick={() => loadReport(selectedProduct, from, to, selectedWarehouse)}
            disabled={loading || !selectedProduct}
            className="flex items-center gap-2 px-3.5 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            Segarkan
          </button>
        </div>
      </div>

      {/* Notifikasi Error */}
      {error && (
        <div className="flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700 shadow-sm">
          <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-red-600" />
          <span>{error}</span>
        </div>
      )}

      {/* Filter Produk, Gudang & Periode Tanggal */}
      <form onSubmit={handleFilter} className="card p-5 shadow-sm rounded-xl border border-slate-200 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          {/* Pilih Produk */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Pilih Produk Medis *
            </label>
            <SearchableSelect
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target ? e.target.value : e)}
              placeholder="-- Cari Produk --"
              required
            >
              {products.map((p) => (
                <option key={p.id} value={p.kode_produk}>
                  {p.kode_produk} &mdash; {p.nama_produk} ({p.satuan || 'pcs'})
                </option>
              ))}
            </SearchableSelect>
          </div>

          {/* Filter Gudang */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Filter Gudang Tertentu
            </label>
            <SearchableSelect
              value={selectedWarehouse}
              onChange={(e) => setSelectedWarehouse(e.target ? e.target.value : e)}
              placeholder="-- Semua Gudang Penyimpanan --"
            >
              <option value="">-- Semua Gudang Penyimpanan --</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.nama_gudang} ({w.kode_gudang})
                </option>
              ))}
            </SearchableSelect>
          </div>

          {/* Dari Tanggal */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Dari Tanggal
            </label>
            <input
              type="date"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Sampai Tanggal */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Sampai Tanggal
            </label>
            <input
              type="date"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="flex justify-end gap-2.5 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={clearFilter}
            className="px-4 py-2 text-xs font-semibold text-slate-600 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition"
          >
            Reset Filter
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 shadow-sm transition"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Terapkan Filter
          </button>
        </div>
      </form>

      {/* Konten Kartu Stok */}
      {loading ? (
        <div className="p-16 text-center text-slate-500">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-3 text-indigo-600" />
          <p className="text-sm">Menghitung riwayat kartu stok realtime...</p>
        </div>
      ) : !report ? (
        <div className="p-16 text-center text-slate-400 bg-white rounded-xl border border-slate-200">
          <ClipboardList className="w-12 h-12 mx-auto mb-3 text-slate-300 stroke-1" />
          <p className="text-base font-semibold text-slate-600">Pilih Produk Medis</p>
          <p className="text-xs text-slate-400 mt-1">
            Silakan pilih produk pada filter di atas untuk melihat buku pembantu kartu stok.
          </p>
        </div>
      ) : (
        <>
          {/* Ringkasan Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Info Produk */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-xs font-medium text-slate-500">Produk Terpilih</span>
              <p className="text-base font-bold text-slate-800 mt-0.5 truncate">{report.product.nama_produk}</p>
              <p className="text-xs text-slate-500 mt-1">
                Kode: <strong>{report.product.kode_produk}</strong> &bull; Rak: <strong>{report.product.kode_rak || '-'}</strong>
              </p>
            </div>

            {/* Total Masuk */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
                <ArrowDownLeft className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-medium text-slate-500">Total Masuk (Periode Ini)</span>
                <p className="text-xl font-extrabold text-emerald-700">
                  +{formatNumber(report.ringkasan.total_masuk)} {report.product.satuan || 'pcs'}
                </p>
                {Number(report.product.isi_per_kemasan) > 1 && (
                  <p className="text-xs font-semibold text-emerald-600">
                    ≈ +{formatNumber(Number((report.ringkasan.total_masuk / report.product.isi_per_kemasan).toFixed(2)))} {report.product.satuan_besar || 'BOX'}
                  </p>
                )}
              </div>
            </div>

            {/* Total Keluar */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-orange-50 border border-orange-100 flex items-center justify-center text-orange-600">
                <ArrowUpRight className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-medium text-slate-500">Total Keluar (Periode Ini)</span>
                <p className="text-xl font-extrabold text-orange-700">
                  -{formatNumber(report.ringkasan.total_keluar)} {report.product.satuan || 'pcs'}
                </p>
                {Number(report.product.isi_per_kemasan) > 1 && (
                  <p className="text-xs font-semibold text-orange-600">
                    ≈ -{formatNumber(Number((report.ringkasan.total_keluar / report.product.isi_per_kemasan).toFixed(2)))} {report.product.satuan_besar || 'BOX'}
                  </p>
                )}
              </div>
            </div>

            {/* Saldo Akhir */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600">
                <Layers className="w-6 h-6" />
              </div>
              <div>
                <span className="text-xs font-medium text-slate-500">Saldo Akhir Fisik</span>
                <p className="text-xl font-extrabold text-indigo-700">
                  {formatNumber(report.ringkasan.saldo)} {report.product.satuan || 'pcs'}
                </p>
                {Number(report.product.isi_per_kemasan) > 1 && (
                  <p className="text-xs font-semibold text-indigo-600">
                    ≈ {formatNumber(Number((report.ringkasan.saldo / report.product.isi_per_kemasan).toFixed(2)))} {report.product.satuan_besar || 'BOX'}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Tabel Mutasi Stok */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ClipboardList className="w-4 h-4 text-indigo-600" />
                <h2 className="text-sm font-bold text-slate-800">
                  Buku Mutasi Saldo Berjalan &mdash; {report.product.nama_produk}
                </h2>
              </div>
              <div className="flex items-center gap-3">
                {Number(report.ringkasan?.saldo_awal || 0) > 0 && (
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 border border-blue-200">
                    Saldo Awal: {formatNumber(report.ringkasan.saldo_awal)} {report.product.satuan || 'pcs'}
                  </span>
                )}
                <span className="text-xs text-slate-500">
                  Total Mutasi: <strong>{report.rows.length} catatan</strong>
                </span>
              </div>
            </div>

            {report.rows.length === 0 ? (
              <div className="p-12 text-center text-slate-400">
                <p className="text-sm font-medium text-slate-600">Tidak ada mutasi stok pada periode filter yang dipilih.</p>
                <p className="text-xs text-slate-400 mt-1">Coba kosongkan filter tanggal untuk melihat seluruh riwayat.</p>
              </div>
            ) : (
              (() => {
                const { pageItems, totalPages, safePage } = paginate(report.rows, page, pageSize);
                return (
                  <>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-sm text-slate-600">
                        <thead className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600 uppercase">
                          <tr>
                            <th className="py-3 px-4">Tanggal & Waktu</th>
                            <th className="py-3 px-4">Gudang</th>
                            <th className="py-3 px-4">No. Lot / Batch</th>
                            <th className="py-3 px-4">Tipe Mutasi</th>
                            <th className="py-3 px-4 text-right text-emerald-700">Masuk (+)</th>
                            <th className="py-3 px-4 text-right text-orange-700">Keluar (-)</th>
                            <th className="py-3 px-4 text-right font-bold text-slate-800">Sisa Stok</th>
                            <th className="py-3 px-4">Referensi Dokumen</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {pageItems.map((row) => {
                            const badgeInfo = MUTATION_BADGES[row.tipe] || {
                              label: row.tipe,
                              color: 'bg-slate-100 text-slate-700 border-slate-200',
                            };
                            const isPositive = POSITIVE_TYPES.includes(row.tipe);

                            return (
                              <tr key={row.id} className="hover:bg-slate-50/60 transition">
                                <td className="py-3 px-4 whitespace-nowrap text-xs text-slate-600 font-medium">
                                  {formatDateTime(row.tanggal_mutasi)}
                                </td>
                                <td className="py-3 px-4 text-xs font-semibold text-slate-700">
                                  {row.nama_gudang || 'Pusat Logistik'}
                                </td>
                                <td className="py-3 px-4 font-mono text-xs font-bold text-slate-800">
                                  {row.nomor_lot}
                                </td>
                                <td className="py-3 px-4">
                                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold border ${badgeInfo.color}`}>
                                    {badgeInfo.label}
                                  </span>
                                </td>
                                <td className="py-3 px-4 text-right font-bold text-emerald-600">
                                  {isPositive ? `+${formatNumber(row.qty_perubahan)}` : '-'}
                                </td>
                                <td className="py-3 px-4 text-right font-bold text-orange-600">
                                  {!isPositive ? `-${formatNumber(row.qty_perubahan)}` : '-'}
                                </td>
                                <td className="py-3 px-4 text-right font-extrabold text-slate-800">
                                  {formatNumber(row.qty_sisa)}
                                </td>
                                <td className="py-3 px-4 text-xs font-medium text-slate-600">
                                  {row.referensi || '-'}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                    <Pagination
                      page={safePage}
                      totalPages={totalPages}
                      onPage={setPage}
                      totalItems={report.rows.length}
                      pageSize={pageSize}
                      onPageSize={(s) => {
                        setPageSize(s);
                        setPage(1);
                      }}
                      label="catatan mutasi"
                    />
                  </>
                );
              })()
            )}
          </div>
        </>
      )}
    </div>
  );
}
