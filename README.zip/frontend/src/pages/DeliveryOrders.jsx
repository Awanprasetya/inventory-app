import { useEffect, useState } from 'react';
import {
  Truck,
  Plus,
  Eye,
  Trash2,
  Loader2,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  XCircle,
  ScanBarcode,
  Barcode,
  Package,
  Sparkles,
  Layers,
  Clock,
  Building,
  Printer,
  Sliders,
  RefreshCw,
  FileSpreadsheet,
} from 'lucide-react';
import api, { getErrorMessage, formatDate, formatNumber } from '../services/api.js';
import Modal from '../components/Modal.jsx';
import Pagination, { paginate } from '../components/Pagination.jsx';
import SearchableSelect from '../components/SearchableSelect.jsx';
import { confirmDelete, toastSuccess, alertError } from '../utils/alert.js';
import { exportToExcel } from '../utils/exportHelper.js';
import ReportCustomizerModal, {
  loadSavedReportConfig,
} from '../components/ReportCustomizerModal.jsx';
import PrintableReportHeader from '../components/PrintableReportHeader.jsx';
import PrintableReportSignatures from '../components/PrintableReportSignatures.jsx';
import PrintableInvoiceModal from '../components/PrintableInvoiceModal.jsx';

const PAGE_SIZE = 10;

const statusBadges = {
  DRAFT: 'bg-slate-100 text-slate-700',
  SHIPPED: 'bg-blue-100 text-blue-700',
  DELIVERED: 'bg-emerald-100 text-emerald-700',
};

export default function DeliveryOrders() {
  const [dos, setDos] = useState([]);
  const [sos, setSos] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  // Kustomisasi Laporan State
  const [reportCustomizerOpen, setReportCustomizerOpen] = useState(false);
  const [reportConfig, setReportConfig] = useState(loadSavedReportConfig);

  // Detail Modal
  const [detailModal, setDetailModal] = useState(false);
  const [activeDo, setActiveDo] = useState(null);

  // Cetak Dokumen Detail DO Modal
  const [invoiceModalOpen, setInvoiceModalOpen] = useState(false);
  const [selectedInvoiceData, setSelectedInvoiceData] = useState(null);
  const [loadingInvoice, setLoadingInvoice] = useState(false);

  // Add Modal state
  const [addModal, setAddModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [availableLots, setAvailableLots] = useState([]);
  const [loadingLots, setLoadingLots] = useState(false);
  const [selectedSoData, setSelectedSoData] = useState(null);
  const [scanInput, setScanInput] = useState('');

  const handlePrintRow = async (doItem) => {
    setSelectedInvoiceData(doItem);
    setInvoiceModalOpen(true);
    setLoadingInvoice(true);
    try {
      const { data } = await api.get(`/delivery-orders/${doItem.id}`);
      setSelectedInvoiceData(data.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoadingInvoice(false);
    }
  };

  const [form, setForm] = useState({
    no_do: '',
    so_id: '',
    customer_id: '',
    tanggal_do: new Date().toISOString().split('T')[0],
    status: 'DRAFT',
    items: [{ nomor_lot: '', kemasan_count: '1', qty_kirim: 1, lot_info: null }],
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [doRes, soRes, custRes, prodRes] = await Promise.all([
        api.get('/delivery-orders', {
          params: { status: statusFilter || undefined, search: search.trim() || undefined },
        }),
        api.get('/sales-orders'),
        api.get('/customers'),
        api.get('/products'),
      ]);
      setDos(doRes.data.data || []);
      setSos(soRes.data.data || []);
      setCustomers(custRes.data.data || []);
      setProducts(prodRes.data.data || []);
      setError('');
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => loadData(), 300);
    return () => clearTimeout(timer);
  }, [statusFilter, search]);

  const flash = (msg) => {
    setSuccess(msg);
    setTimeout(() => setSuccess(''), 4000);
  };

  const fetchAvailableLots = async () => {
    setLoadingLots(true);
    try {
      const res = await api.get('/lots');
      if (res.data.success) {
        setAvailableLots(res.data.data || []);
      }
    } catch (_) {
      /* ignore */
    } finally {
      setLoadingLots(false);
    }
  };

  const resolveIsiPerKemasan = (lotInfo) => {
    if (!lotInfo) return 1;
    const isiLot = Number(lotInfo.isi_per_kemasan);
    if (isiLot > 0) return isiLot;
    const prod = products.find((p) => p.kode_produk === lotInfo.kode_produk);
    const isiProd = Number(prod?.isi_per_kemasan);
    if (isiProd > 0) return isiProd;
    return 1;
  };

  const resolveSatuanBesar = (lotInfo) => {
    if (lotInfo?.satuan_besar) return lotInfo.satuan_besar;
    const prod = products.find((p) => p.kode_produk === lotInfo?.kode_produk);
    return prod?.satuan_besar || 'BOX';
  };

  const handleOpenAddModal = () => {
    fetchAvailableLots();
    setSelectedSoData(null);
    setScanInput('');
    setForm({
      no_do: '',
      so_id: '',
      customer_id: '',
      tanggal_do: new Date().toISOString().split('T')[0],
      status: 'DRAFT',
      items: [{ nomor_lot: '', kemasan_count: '1', qty_kirim: 1, lot_info: null }],
    });
    setAddModal(true);
  };

  const openDetail = async (id) => {
    try {
      const { data } = await api.get(`/delivery-orders/${id}`);
      setActiveDo(data.data);
      setDetailModal(true);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const changeStatus = async (id, newStatus) => {
    try {
      const { data } = await api.put(`/delivery-orders/${id}/status`, { status: newStatus });
      flash(data.message);
      toastSuccess(data.message);
      if (activeDo && activeDo.id === id) {
        setActiveDo((prev) => ({ ...prev, status: newStatus }));
      }
      loadData();
    } catch (err) {
      const msg = getErrorMessage(err);
      setError(msg);
      alertError('Gagal Mengubah Status', msg);
    }
  };

  const deleteDo = async (d) => {
    const confirmed = await confirmDelete({
      title: `Hapus Delivery Order?`,
      text: `DO "${d.no_do}" beserta seluruh detailnya akan dihapus permanen!`,
    });
    if (!confirmed) return;
    try {
      const { data } = await api.delete(`/delivery-orders/${d.id}`);
      flash(data.message);
      toastSuccess(data.message);
      loadData();
    } catch (err) {
      const msg = getErrorMessage(err);
      setError(msg);
      alertError('Gagal Menghapus DO', msg);
    }
  };

  // When SO selected, auto fill customer and fetch SO detail
  const handleSoSelect = async (soIdVal) => {
    const selectedSo = sos.find((s) => s.id === Number(soIdVal));
    setForm((f) => ({
      ...f,
      so_id: soIdVal,
      customer_id: selectedSo && selectedSo.customer_id ? String(selectedSo.customer_id) : f.customer_id,
    }));

    if (!soIdVal) {
      setSelectedSoData(null);
      return;
    }

    try {
      const { data } = await api.get(`/sales-orders/${soIdVal}`);
      setSelectedSoData(data.data);
      toastSuccess(`Data Sales Order ${data.data.no_so} berhasil dimuat`);
    } catch (_) {
      setSelectedSoData(null);
    }
  };

  // Auto-fill lot rows from Sales Order items
  const autoFillLotsFromSo = () => {
    if (!selectedSoData || !selectedSoData.details || selectedSoData.details.length === 0) {
      alertError('Informasi', 'Tidak ada item detail pada Sales Order ini.');
      return;
    }

    const newItems = [];
    for (const soItem of selectedSoData.details) {
      const neededQty = Math.max(0, Number(soItem.qty_pesanan) - Number(soItem.qty_terkirim || 0));
      if (neededQty <= 0) continue;

      // Find available lots for this product code
      const matchingLots = availableLots.filter(
        (l) => l.kode_produk === soItem.kode_produk && Number(l.stok_qty) > 0 && l.status !== 'QUARANTINE'
      );

      if (matchingLots.length > 0) {
        // Pick top recommended lot
        const topLot = matchingLots[0];
        const isi = resolveIsiPerKemasan(topLot);
        const sendQty = Math.min(neededQty, Number(topLot.stok_qty));
        const kemasan = isi > 1 ? (sendQty / isi).toFixed(2).replace(/\.00$/, '') : String(sendQty);

        newItems.push({
          nomor_lot: topLot.nomor_lot,
          kemasan_count: kemasan,
          qty_kirim: sendQty,
          lot_info: topLot,
        });
      } else {
        // Fallback row if no lot available in stock yet
        newItems.push({
          nomor_lot: '',
          kemasan_count: '1',
          qty_kirim: neededQty,
          lot_info: null,
          so_product_name: soItem.nama_produk,
        });
      }
    }

    if (newItems.length > 0) {
      setForm((f) => ({ ...f, items: newItems }));
      toastSuccess(`Otomatisi Lot dari SO: ${newItems.length} baris barang disiapkan.`);
    } else {
      alertError('Informasi', 'Seluruh item pada Sales Order ini sudah terkirim sepenuhnya.');
    }
  };

  // Scan Barcode Lot
  const handleScanLotBarcode = async () => {
    const code = scanInput.trim();
    if (!code) return;

    let lot = availableLots.find((l) => l.nomor_lot.toUpperCase() === code.toUpperCase());
    if (!lot) {
      try {
        const res = await api.get(`/lots/${encodeURIComponent(code)}`);
        lot = res.data.data;
      } catch (_) {
        lot = null;
      }
    }

    if (!lot) {
      alertError('Lot Tidak Ditemukan', `Nomor lot / Barcode "${code}" tidak ditemukan dalam sistem.`);
      return;
    }

    const isi = resolveIsiPerKemasan(lot);
    const satuanBesar = resolveSatuanBesar(lot);
    const existingIndex = form.items.findIndex((i) => i.nomor_lot === lot.nomor_lot);

    if (existingIndex >= 0) {
      // Increment Kemasan count by 1
      const currentKemasan = Number(form.items[existingIndex].kemasan_count) || 1;
      const nextKemasan = currentKemasan + 1;
      const nextQty = Math.round(nextKemasan * isi * 100) / 100;

      setForm((f) => ({
        ...f,
        items: f.items.map((item, idx) =>
          idx === existingIndex
            ? {
                ...item,
                kemasan_count: String(nextKemasan),
                qty_kirim: nextQty,
                lot_info: lot,
              }
            : item
        ),
      }));
      toastSuccess(`📦 +1 ${satuanBesar} pada Lot ${lot.nomor_lot} (${nextKemasan} ${satuanBesar} = ${nextQty} ${lot.satuan || 'PCS'})`);
    } else {
      // Add new row
      const initialKemasan = '1';
      const initialQty = isi;
      setForm((f) => ({
        ...f,
        items: [
          ...f.items.filter((i) => i.nomor_lot !== ''),
          {
            nomor_lot: lot.nomor_lot,
            kemasan_count: initialKemasan,
            qty_kirim: initialQty,
            lot_info: lot,
          },
        ],
      }));
      toastSuccess(`📦 Lot ${lot.nomor_lot} ditambahkan (1 ${satuanBesar} = ${initialQty} ${lot.satuan || 'PCS'})`);
    }
    setScanInput('');
  };

  // --- Add Form Item Handlers ---
  const addItemRow = () => {
    setForm((f) => ({
      ...f,
      items: [...f.items, { nomor_lot: '', kemasan_count: '1', qty_kirim: 1, lot_info: null }],
    }));
  };

  const removeItemRow = (idx) => {
    setForm((f) => ({
      ...f,
      items: f.items.filter((_, i) => i !== idx),
    }));
  };

  const handleItemLotChange = async (idx, nomorLotVal) => {
    const lot = availableLots.find((l) => l.nomor_lot === nomorLotVal);
    let lotInfo = lot || null;

    if (!lotInfo && nomorLotVal) {
      try {
        const res = await api.get(`/lots/${encodeURIComponent(nomorLotVal)}`);
        lotInfo = res.data.data;
      } catch (_) {
        lotInfo = null;
      }
    }

    const isi = resolveIsiPerKemasan(lotInfo);
    const initialQty = isi; // 1 Kemasan (BOX) = isi PCS!

    setForm((f) => ({
      ...f,
      items: f.items.map((item, i) =>
        i === idx
          ? {
              ...item,
              nomor_lot: nomorLotVal,
              lot_info: lotInfo,
              kemasan_count: '1',
              qty_kirim: initialQty,
            }
          : item
      ),
    }));
  };

  const handleItemKemasanChange = (idx, kemasanVal) => {
    setForm((f) => ({
      ...f,
      items: f.items.map((item, i) => {
        if (i !== idx) return item;
        const isi = resolveIsiPerKemasan(item.lot_info);
        const kNum = Number(kemasanVal) || 0;
        const calcQty = Math.round(kNum * isi * 100) / 100;
        return {
          ...item,
          kemasan_count: kemasanVal,
          qty_kirim: calcQty,
        };
      }),
    }));
  };

  const handleItemQtyChange = (idx, qtyVal) => {
    setForm((f) => ({
      ...f,
      items: f.items.map((item, i) => {
        if (i !== idx) return item;
        const isi = resolveIsiPerKemasan(item.lot_info);
        const qNum = Number(qtyVal) || 0;
        const calcKemasan = isi > 1 ? (qNum / isi).toFixed(2).replace(/\.00$/, '') : String(qNum);
        return {
          ...item,
          qty_kirim: qtyVal,
          kemasan_count: calcKemasan,
        };
      }),
    }));
  };

  const submitAdd = async (e) => {
    e.preventDefault();
    if (form.items.length === 0) {
      setError('Minimal 1 lot pengiriman dalam DO');
      return;
    }
    const emptyLot = form.items.find((i) => !i.nomor_lot.trim());
    if (emptyLot) {
      alertError('Validasi Input', 'Semua baris barang wajib memiliki Nomor Lot.');
      return;
    }

    setSaving(true);
    setError('');
    try {
      const { data } = await api.post('/delivery-orders', {
        ...form,
        so_id: form.so_id ? Number(form.so_id) : null,
        customer_id: form.customer_id ? Number(form.customer_id) : null,
        items: form.items.map((i) => ({ nomor_lot: i.nomor_lot.trim(), qty_kirim: Number(i.qty_kirim) })),
      });
      flash(data.message);
      toastSuccess(data.message);
      setAddModal(false);
      setForm({
        no_do: '',
        so_id: '',
        customer_id: '',
        tanggal_do: new Date().toISOString().split('T')[0],
        status: 'DRAFT',
        items: [{ nomor_lot: '', kemasan_count: '1', qty_kirim: 1, lot_info: null }],
      });
      loadData();
    } catch (err) {
      const msg = getErrorMessage(err);
      setError(msg);
      alertError('Gagal Membuat DO', msg);
    } finally {
      setSaving(false);
    }
  };

  // Calculate overall totals in modal
  const totalQtyPcs = form.items.reduce((sum, item) => sum + Number(item.qty_kirim || 0), 0);
  const totalKemasanBox = form.items.reduce((sum, item) => sum + Number(item.kemasan_count || 0), 0);

  return (
    <div className="space-y-6">
      {/* Header Kop Resmi Khusus Cetak / Print Mode */}
      <div className="hidden print:block">
        <PrintableReportHeader
          companyName={reportConfig.companyName}
          companyAddress={reportConfig.companyAddress}
          companyContact={reportConfig.companyContact}
          companyLogo={reportConfig.companyLogo}
          showCompanyHeader={reportConfig.showCompanyHeader}
          title="LAPORAN REKAPITULASI DELIVERY ORDERS (SURAT JALAN / PENGIRIMAN)"
          subtitle={`Status: ${statusFilter || 'Semua Status'} | Per Tanggal: ${formatDate(new Date())}`}
          docNo="REP-DO"
        />
      </div>

      {/* Notifikasi */}
      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 print:hidden">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {success && (
        <div className="flex items-start gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 print:hidden">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* --- Tabel DO --- */}
      <div className="card">
        <div className="card-header flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-2">
            <Truck className="h-5 w-5 text-blue-600" />
            <div>
              <h2 className="text-sm font-semibold text-slate-800">Delivery Orders (DO / Surat Jalan)</h2>
              <p className="text-xs text-slate-500">{dos.length} dokumen DO</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <SearchableSelect
              className="w-36"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              placeholder="Semua Status"
              searchPlaceholder="Cari status..."
              options={[
                { value: '', label: 'Semua Status' },
                { value: 'DRAFT', label: 'DRAFT' },
                { value: 'SHIPPED', label: 'SHIPPED' },
                { value: 'DELIVERED', label: 'DELIVERED' },
              ]}
            />
            <input
              className="input w-48"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari No DO / SO / Customer..."
            />
            <button
              type="button"
              onClick={() => setReportCustomizerOpen(true)}
              className="btn-secondary flex items-center gap-1.5 text-xs font-semibold"
              title="Kustomisasi Kop Perusahaan & Format Cetak"
            >
              <Sliders className="h-3.5 w-3.5 text-blue-600" />
              Kustomisasi
            </button>
            <button
              type="button"
              onClick={() => {
                const headers = ['No. DO', 'Ref SO', 'Customer', 'Tanggal DO', 'Status'];
                const rows = dos.map((d) => [
                  d.no_do || '',
                  d.no_so || '',
                  d.nama_customer || '',
                  formatDate(d.tanggal_do),
                  d.status || '',
                ]);
                exportToExcel('Rekap_Delivery_Orders_DO', headers, rows);
              }}
              className="btn-secondary flex items-center gap-1.5 text-xs font-semibold"
              title="Export Delivery Orders ke Excel"
            >
              <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
              Export Excel
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="btn-secondary flex items-center gap-1.5 text-xs font-semibold"
              title="Cetak Laporan Delivery Orders ke PDF"
            >
              <Printer className="h-3.5 w-3.5 text-blue-600" />
              Cetak / Export PDF
            </button>
            <button type="button" onClick={handleOpenAddModal} className="btn-primary">
              <Plus className="h-4 w-4" /> Buat DO Baru
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-10 text-sm text-slate-500">
            <Loader2 className="h-4 w-4 animate-spin" /> Memuat data Delivery Orders...
          </div>
        ) : dos.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-slate-500">Belum ada Delivery Order.</p>
        ) : (
          (() => {
            const { pageItems, totalPages, safePage } = paginate(dos, page, pageSize);
            return (
              <>
                <div className="overflow-x-auto print:overflow-visible">
                  <table className="table-base print:w-full">
                    <thead>
                      <tr>
                        <th>No DO</th>
                        <th>Ref SO</th>
                        <th>Customer</th>
                        <th>Tanggal DO</th>
                        <th>Status</th>
                        <th className="print:hidden">
                          <span className="sr-only">Aksi</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {dos.map((d, index) => {
                        const isCurrentPage = index >= (safePage - 1) * pageSize && index < safePage * pageSize;
                        return (
                          <tr key={d.id} className={`hover:bg-slate-50 ${isCurrentPage ? '' : 'hidden print:table-row'}`}>
                            <td className="font-medium text-slate-700">{d.no_do}</td>
                            <td className="text-xs text-slate-600">{d.no_so || '-'}</td>
                            <td>{d.nama_customer || '-'}</td>
                            <td className="text-xs text-slate-500">{formatDate(d.tanggal_do)}</td>
                            <td>
                              <span className={`badge ${statusBadges[d.status] || 'bg-slate-100'}`}>
                                {d.status}
                              </span>
                            </td>
                            <td className="print:hidden">
                              <div className="flex justify-end gap-1">
                                <button
                                  type="button"
                                  onClick={() => handlePrintRow(d)}
                                  className="rounded p-1.5 text-blue-600 hover:bg-blue-50 transition"
                                  title="Cetak Surat Jalan (DO)"
                                  aria-label={`Cetak ${d.no_do}`}
                                >
                                  <Printer className="h-4 w-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openDetail(d.id)}
                                  className="rounded p-1.5 text-slate-500 hover:bg-blue-50 hover:text-blue-600 transition"
                                  title="Lihat Detail DO"
                                  aria-label={`Detail ${d.no_do}`}
                                >
                                  <Eye className="h-4 w-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => deleteDo(d)}
                                  className="rounded p-1.5 text-slate-500 hover:bg-red-50 hover:text-red-600 transition"
                                  title="Hapus DO"
                                  aria-label={`Hapus ${d.no_do}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <div className="print:hidden">
                  <Pagination
                    page={safePage}
                    totalPages={totalPages}
                    onPage={setPage}
                    totalItems={dos.length}
                    pageSize={pageSize}
                    onPageSize={(sz) => {
                      setPageSize(sz);
                      setPage(1);
                    }}
                    label="dokumen DO"
                  />
                </div>

                {/* Blok Tanda Tangan Cetak PDF */}
                <div className="hidden print:block avoid-break mt-6">
                  <PrintableReportSignatures
                    city={reportConfig.signatureCity}
                    date={reportConfig.signatureDate}
                    signer1={reportConfig.signer1}
                    signer2={reportConfig.signer2}
                    signer3={reportConfig.signer3}
                    companyStamp={reportConfig.companyStamp}
                    showStamp={reportConfig.showStamp}
                    stampPosition={reportConfig.stampPosition}
                    showSignatures={reportConfig.showSignatures}
                    footerNote={reportConfig.footerNote}
                  />
                </div>
              </>
            );
          })()
        )}
      </div>

      {/* Modal Kustomisasi Laporan */}
      <ReportCustomizerModal
        isOpen={reportCustomizerOpen}
        onClose={() => setReportCustomizerOpen(false)}
        config={reportConfig}
        onChangeConfig={setReportConfig}
        activeReportTitle="Laporan Delivery Orders (DO / Surat Jalan)"
      />

      {/* --- Modal Detail DO --- */}
      {activeDo && (
        <Modal
          isOpen={detailModal}
          title={`Detail DO: ${activeDo.no_do}`}
          onClose={() => setDetailModal(false)}
        >
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 rounded-lg bg-slate-50 p-3 text-xs">
              <div>
                <span className="text-slate-500">Ref SO:</span>{' '}
                <strong className="text-slate-700">{activeDo.no_so || '-'}</strong>
              </div>
              <div>
                <span className="text-slate-500">Customer:</span>{' '}
                <strong className="text-slate-700">{activeDo.nama_customer || '-'}</strong>
              </div>
              <div>
                <span className="text-slate-500">Tanggal DO:</span>{' '}
                <strong className="text-slate-700">{formatDate(activeDo.tanggal_do)}</strong>
              </div>
              <div>
                <span className="text-slate-500">Status Saat Ini:</span>{' '}
                <span className={`badge ${statusBadges[activeDo.status]}`}>
                  {activeDo.status}
                </span>
              </div>
            </div>

            {/* Ubah Status */}
            <div className="flex items-center gap-2 border-t border-b border-slate-100 py-3">
              <span className="text-xs font-medium text-slate-600">Ubah Status DO:</span>
              {['DRAFT', 'SHIPPED', 'DELIVERED'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => changeStatus(activeDo.id, st)}
                  disabled={activeDo.status === st}
                  className={`rounded px-2.5 py-1 text-xs font-semibold ${
                    activeDo.status === st
                      ? 'bg-slate-800 text-white'
                      : 'border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-50'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <h3 className="text-xs font-semibold uppercase text-slate-500">Detail Lot Pengiriman</h3>
            <div className="overflow-x-auto">
              <table className="table-base text-xs">
                <thead>
                  <tr>
                    <th>Nomor Lot</th>
                    <th>Kode Produk</th>
                    <th>Nama Produk</th>
                    <th className="text-right">Qty Kirim</th>
                  </tr>
                </thead>
                <tbody>
                  {activeDo.details?.map((d) => (
                    <tr key={d.id}>
                      <td className="font-medium text-slate-700">{d.nomor_lot}</td>
                      <td>{d.kode_produk || '-'}</td>
                      <td>{d.nama_produk || '-'}</td>
                      <td className="text-right font-semibold text-blue-600">
                        <p>{formatNumber(d.qty_kirim)} {d.satuan || ''}</p>
                        {Number(d.isi_per_kemasan) > 1 && (
                          <p className="text-[11px] text-indigo-600 font-medium">
                            ≈ {formatNumber(Number((d.qty_kirim / d.isi_per_kemasan).toFixed(1)))} {d.satuan_besar || 'BOX'}
                          </p>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                type="button"
                onClick={() => handlePrintRow(activeDo)}
                className="btn-secondary !text-xs flex items-center gap-1.5 text-blue-600 hover:text-blue-700 font-semibold"
                title="Cetak Dokumen Surat Jalan (DO) Resmi"
              >
                <Printer className="h-4 w-4" /> Cetak Surat Jalan (DO)
              </button>
              <button type="button" onClick={() => setDetailModal(false)} className="btn-secondary">
                Tutup
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* --- Modal Buat DO Baru --- */}
      <Modal
        isOpen={addModal}
        title="Buat Delivery Order Baru (Pengiriman Barang / Surat Jalan)"
        onClose={() => setAddModal(false)}
        maxWidth="max-w-6xl"
      >
        <form onSubmit={submitAdd} className="space-y-5">
          {/* Form Header Info */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1" htmlFor="no_do">
                Nomor DO
              </label>
              <input
                id="no_do"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none"
                value={form.no_do}
                onChange={(e) => setForm({ ...form, no_do: e.target.value })}
                placeholder="Auto jika dikosongkan"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1" htmlFor="so_id">
                Ref Sales Order (SO)
              </label>
              <SearchableSelect
                id="so_id"
                value={form.so_id}
                onChange={(e) => handleSoSelect(e.target.value)}
                placeholder="-- Tanpa SO / Independen --"
                searchPlaceholder="Cari No SO / Customer..."
                options={[
                  { value: '', label: '-- Tanpa SO / Independen --' },
                  ...sos.map((s) => ({
                    value: s.id,
                    label: `${s.no_so} (${s.nama_customer || 'Tanpa Customer'})`,
                  })),
                ]}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1" htmlFor="customer_id_do">
                Customer Receiver
              </label>
              <SearchableSelect
                id="customer_id_do"
                value={form.customer_id}
                onChange={(e) => setForm({ ...form, customer_id: e.target.value })}
                placeholder="-- Pilih Customer --"
                searchPlaceholder="Cari kode atau nama customer..."
                options={[
                  { value: '', label: '-- Pilih Customer --' },
                  ...customers.map((c) => ({
                    value: c.id,
                    label: `${c.kode_customer} — ${c.nama_customer}`,
                  })),
                ]}
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-slate-600 mb-1" htmlFor="tanggal_do">
                Tanggal DO <span className="text-red-500">*</span>
              </label>
              <input
                id="tanggal_do"
                type="date"
                className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-teal-500 focus:outline-none"
                value={form.tanggal_do}
                onChange={(e) => setForm({ ...form, tanggal_do: e.target.value })}
                required
              />
            </div>
          </div>

          {/* Section Ref SO (If SO is selected) */}
          {selectedSoData && (
            <div className="rounded-xl border border-blue-200 bg-blue-50/70 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Truck className="h-5 w-5 text-blue-600" />
                  <span className="text-sm font-bold text-blue-900">
                    Item Pesanan dari SO #{selectedSoData.no_so}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={autoFillLotsFromSo}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-sm hover:bg-blue-700 transition"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  Otomatis Ambil Lot FEFO / FIFO untuk SO Ini
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs bg-white rounded-lg border border-blue-100 overflow-hidden shadow-xs">
                  <thead className="bg-blue-100/50 font-semibold text-blue-900">
                    <tr>
                      <th className="px-3.5 py-2">Produk</th>
                      <th className="px-3.5 py-2 text-right">Qty Pesan SO</th>
                      <th className="px-3.5 py-2 text-right">Telah Dikirim</th>
                      <th className="px-3.5 py-2 text-right">Sisa Kirim</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-blue-50 text-slate-700">
                    {selectedSoData.details?.map((item) => {
                      const remaining = Math.max(0, Number(item.qty_pesanan) - Number(item.qty_terkirim || 0));
                      return (
                        <tr key={item.id}>
                          <td className="px-3.5 py-2 font-medium">
                            {item.kode_produk} — {item.nama_produk}
                          </td>
                          <td className="px-3.5 py-2 text-right font-semibold">
                            {formatNumber(item.qty_pesanan)} {item.satuan}
                          </td>
                          <td className="px-3.5 py-2 text-right text-emerald-600 font-semibold">
                            {formatNumber(item.qty_terkirim || 0)} {item.satuan}
                          </td>
                          <td className="px-3.5 py-2 text-right text-blue-700 font-bold">
                            {formatNumber(remaining)} {item.satuan}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section Quick Scan Barcode Lot */}
          <div className="rounded-xl border border-teal-200 bg-teal-50/60 p-3.5 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-teal-800 min-w-[220px]">
              <ScanBarcode className="h-5 w-5 text-teal-600 shrink-0" />
              <div>
                <p className="text-xs font-bold uppercase tracking-wider">Scan Barcode Lot / Box</p>
                <p className="text-[11px] text-teal-600">Scan barcode lot untuk input Qty & Box otomatis</p>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-1 max-w-lg">
              <input
                type="text"
                value={scanInput}
                onChange={(e) => setScanInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleScanLotBarcode();
                  }
                }}
                placeholder="Scan / ketik nomor lot (contoh: LOT-202610-344) lalu tekan Enter..."
                className="w-full rounded-lg border border-teal-300 bg-white px-3.5 py-2 text-xs font-mono font-medium focus:border-teal-600 focus:outline-none shadow-xs"
              />
              <button
                type="button"
                onClick={handleScanLotBarcode}
                className="rounded-lg bg-teal-600 px-4 py-2 text-xs font-semibold text-white hover:bg-teal-700 shrink-0 shadow-xs"
              >
                Scan
              </button>
            </div>
          </div>

          {/* Section Items Table */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold uppercase text-slate-600 flex items-center gap-1.5">
                <Package className="h-4 w-4 text-teal-600" />
                Detail Lot & Kuantitas Barang yang Dikirim
              </h3>
              <button type="button" onClick={addItemRow} className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:text-teal-900">
                <PlusCircle className="h-4 w-4" /> Tambah Baris Lot
              </button>
            </div>

            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[11px] border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3 w-[38%]">Pilih / Scan Nomor Lot</th>
                    <th className="px-4 py-3 w-[36%]">Informasi Produk & Stok Lot</th>
                    <th className="px-4 py-3 w-36 text-center">Jml Kemasan (BOX)</th>
                    <th className="px-4 py-3 w-40 text-right">Total Qty (PCS)</th>
                    <th className="px-4 py-3 w-12 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {form.items.map((item, idx) => {
                    const lotInfo = item.lot_info;
                    const isi = resolveIsiPerKemasan(lotInfo);
                    const satuanBesar = resolveSatuanBesar(lotInfo);
                    const availStock = Number(lotInfo?.stok_qty || 0);
                    const isOverStock = lotInfo && Number(item.qty_kirim) > availStock;
                    const isFefo = lotInfo?.metode_stok === 'FEFO';

                    return (
                      <tr key={idx} className="hover:bg-slate-50 transition-colors">
                        <td className="px-3 py-2.5 align-top">
                          <SearchableSelect
                            value={item.nomor_lot}
                            onChange={(e) => handleItemLotChange(idx, e.target.value)}
                            placeholder="-- Pilih / Scan Lot --"
                            searchPlaceholder="Cari nomor lot atau produk..."
                            options={[
                              { value: '', label: '-- Pilih / Scan Lot --' },
                              ...availableLots.map((l) => ({
                                value: l.nomor_lot,
                                label: `${l.nomor_lot} — ${l.nama_produk} (Stok: ${l.stok_qty} ${l.satuan})`,
                              })),
                            ]}
                          />
                          {!availableLots.find((l) => l.nomor_lot === item.nomor_lot) && item.nomor_lot && (
                            <input
                              type="text"
                              className="w-full mt-1 rounded border border-slate-300 px-2 py-1 text-xs font-mono"
                              value={item.nomor_lot}
                              onChange={(e) => handleItemLotChange(idx, e.target.value)}
                              placeholder="Ketik manual jika belum terdaftar..."
                            />
                          )}
                        </td>

                        <td className="px-3 py-2.5 align-top">
                          {lotInfo ? (
                            <div className="space-y-0.5">
                              <div className="font-semibold text-slate-800">{lotInfo.nama_produk}</div>
                              <div className="text-[11px] text-slate-500 font-mono">
                                Kode: {lotInfo.kode_produk} | Gudang: {lotInfo.nama_gudang || 'Utama'}
                              </div>
                              <div className="flex flex-wrap items-center gap-1.5 text-[11px] pt-0.5">
                                <span className="font-medium text-slate-600">
                                  Stok Tersedia: <strong className="text-slate-900">{formatNumber(availStock)} {lotInfo.satuan || 'PCS'}</strong>
                                </span>
                                {isi > 1 && (
                                  <span className="text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded font-medium">
                                    1 {satuanBesar} = {isi} {lotInfo.satuan || 'PCS'}
                                  </span>
                                )}
                                <span
                                  className={`px-1.5 py-0.5 rounded font-bold text-[10px] ${
                                    isFefo ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                                  }`}
                                >
                                  {lotInfo.metode_stok || 'FIFO'}
                                </span>
                              </div>
                              {isOverStock && (
                                <p className="text-[11px] font-bold text-red-600 flex items-center gap-1 pt-0.5">
                                  <AlertCircle className="h-3.5 w-3.5" /> Qty kirim melebihi stok lot!
                                </p>
                              )}
                            </div>
                          ) : (
                            <div className="text-xs text-slate-400 italic py-1">
                              {item.so_product_name ? `Item SO: ${item.so_product_name}` : 'Pilih lot untuk menampilkan rincian produk & konversi kemasan'}
                            </div>
                          )}
                        </td>

                        <td className="px-3 py-2.5 align-top text-center">
                          <div className="relative">
                            <input
                              type="number"
                              step="any"
                              min="0"
                              className="w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs text-center font-bold focus:border-teal-500 focus:outline-none"
                              value={item.kemasan_count}
                              onChange={(e) => handleItemKemasanChange(idx, e.target.value)}
                              placeholder="1"
                            />
                            <span className="block text-[10px] text-slate-400 mt-0.5 font-semibold">
                              {satuanBesar}
                            </span>
                          </div>
                        </td>

                        <td className="px-3 py-2.5 align-top text-right">
                          <div className="relative">
                            <input
                              type="number"
                              min="1"
                              className="w-full rounded-lg border border-slate-300 px-2 py-1.5 text-xs text-right font-bold text-teal-700 focus:border-teal-500 focus:outline-none"
                              value={item.qty_kirim}
                              onChange={(e) => handleItemQtyChange(idx, e.target.value)}
                              placeholder="Qty PCS"
                              required
                            />
                            <span className="block text-[10px] text-slate-400 mt-0.5 font-semibold">
                              {lotInfo?.satuan || 'PCS'}
                            </span>
                          </div>
                        </td>

                        <td className="px-3 py-2.5 align-top text-center">
                          {form.items.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeItemRow(idx)}
                              className="rounded p-1 text-red-500 hover:bg-red-50"
                              title="Hapus baris lot"
                            >
                              <XCircle className="h-4 w-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Total Footer */}
            <div className="flex items-center justify-between rounded-xl bg-slate-800 text-white p-3 px-4 text-xs font-semibold">
              <span className="text-slate-300">Total Pengiriman DO ({form.items.length} Lot)</span>
              <div className="flex items-center gap-4">
                <span>Total Kemasan: <strong className="text-amber-400 text-sm">{formatNumber(totalKemasanBox)} Kemasan / BOX</strong></span>
                <span>Total Fisik: <strong className="text-emerald-400 text-sm">{formatNumber(totalQtyPcs)} PCS</strong></span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 border-t border-slate-200 pt-4">
            <button type="button" onClick={() => setAddModal(false)} className="btn-secondary">
              Batal
            </button>
            <button type="submit" disabled={saving} className="btn-primary">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              Simpan & Terbitkan Delivery Order
            </button>
          </div>
        </form>
      </Modal>
      {/* Modal Cetak Dokumen Surat Jalan Pengiriman (DO) */}
      <PrintableInvoiceModal
        isOpen={invoiceModalOpen}
        onClose={() => setInvoiceModalOpen(false)}
        type="DO"
        data={selectedInvoiceData}
        loading={loadingInvoice}
      />
    </div>
  );
}
