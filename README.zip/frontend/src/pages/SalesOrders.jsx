import { useEffect, useState } from 'react';
import {
  ShoppingCart,
  Plus,
  Eye,
  Trash2,
  Loader2,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  XCircle,
  Printer,
  Sliders,
  RefreshCw,
  FileSpreadsheet,
} from 'lucide-react';
import api, { getErrorMessage, formatDate, formatNumber, formatRupiah } from '../services/api.js';
import Modal from '../components/Modal.jsx';
import Pagination, { paginate } from '../components/Pagination.jsx';
import SearchableSelect from '../components/SearchableSelect.jsx';
import { confirmDelete, toastSuccess, alertError } from '../utils/alert.js';
import { exportToExcel } from '../utils/exportHelper.js';
import ReportCustomizerModal, {
  loadSavedReportConfig,
} from '../components/ReportCustomizerModal.jsx';
import PrintableReportHeader from '../components/PrintableReportHeader.jsx';
import PrintableReportSignatures from '../components/PrintableReportSignatures.jsx';
import PrintableInvoiceModal from '../components/PrintableInvoiceModal.jsx';

const PAGE_SIZE = 10;

const statusBadges = {
  OPEN: 'bg-blue-100 text-blue-700',
  PROCESSING: 'bg-amber-100 text-amber-700',
  CLOSED: 'bg-emerald-100 text-emerald-700',
  CANCELLED: 'bg-red-100 text-red-700',
};

const calculateDueDate = (dateStr, days) => {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  d.setDate(d.getDate() + Number(days || 0));
  return d.toISOString().split('T')[0];
};

const emptySoForm = {
  no_so: '',
  customer_id: '',
  tanggal_so: new Date().toISOString().split('T')[0],
  termin_hari: 30,
  jatuh_tempo: calculateDueDate(new Date().toISOString().split('T')[0], 30),
  keterangan: '',
  diskon_persen: 0,
  pajak_persen: 11,
  items: [{ kode_produk: '', qty_pesanan: 1, harga_satuan: 0, diskon: 0 }],
};

export default function SalesOrders() {
  const [sos, setSos] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(PAGE_SIZE);

  // Kustomisasi Laporan State
  const [reportCustomizerOpen, setReportCustomizerOpen] = useState(false);
  const [reportConfig, setReportConfig] = useState(loadSavedReportConfig);

  // Detail Modal
  const [detailModal, setDetailModal] = useState(false);
  const [activeSo, setActiveSo] = useState(null);

  // Cetak Dokumen Detail SO Modal
  const [invoiceModalOpen, setInvoiceModalOpen] = useState(false);
  const [selectedInvoiceData, setSelectedInvoiceData] = useState(null);
  const [loadingInvoice, setLoadingInvoice] = useState(false);

  // Add Modal state
  const [addModal, setAddModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(emptySoForm);

  const handlePrintRow = async (so) => {
    setSelectedInvoiceData(so);
    setInvoiceModalOpen(true);
    setLoadingInvoice(true);
    try {
      const { data } = await api.get(`/sales-orders/${so.id}`);
      setSelectedInvoiceData(data.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoadingInvoice(false);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [soRes, custRes, prdRes] = await Promise.all([
        api.get('/sales-orders', {
          params: { status: statusFilter || undefined, search: search.trim() || undefined },
        }),
        api.get('/customers'),
        api.get('/products'),
      ]);
      setSos(soRes.data.data);
      setCustomers(custRes.data.data);
      setProducts(prdRes.data.data);
      setError('');
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => loadData(), 300);
    return () => clearTimeout(timer);
  }, [statusFilter, search]);

  const flash = (msg) => {
    setSuccess(msg);
    setTimeout(() => setSuccess(''), 4000);
  };

  const openDetail = async (id) => {
    try {
      const { data } = await api.get(`/sales-orders/${id}`);
      setActiveSo(data.data);
      setDetailModal(true);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const changeStatus = async (id, newStatus) => {
    try {
      const { data } = await api.put(`/sales-orders/${id}/status`, { status: newStatus });
      flash(data.message);
      toastSuccess(data.message);
      if (activeSo && activeSo.id === id) {
        setActiveSo((prev) => ({ ...prev, status: newStatus }));
      }
      loadData();
    } catch (err) {
      const msg = getErrorMessage(err);
      setError(msg);
      alertError('Gagal Mengubah Status', msg);
    }
  };

  const deleteSo = async (so) => {
    const confirmed = await confirmDelete({
      title: `Hapus Sales Order?`,
      text: `SO "${so.no_so}" beserta seluruh detailnya akan dihapus permanen!`,
    });
    if (!confirmed) return;
    try {
      const { data } = await api.delete(`/sales-orders/${so.id}`);
      flash(data.message);
      toastSuccess(data.message);
      loadData();
    } catch (err) {
      const msg = getErrorMessage(err);
      setError(msg);
      alertError('Gagal Menghapus SO', msg);
    }
  };

  // --- Calculations ---
  const calculateTotals = (currentForm) => {
    const itemsSubtotal = (currentForm.items || []).reduce((sum, item) => {
      const q = Math.max(0, Number(item.qty_pesanan) || 0);
      const h = Math.max(0, Number(item.harga_satuan) || 0);
      const d = Math.max(0, Number(item.diskon) || 0);
      return sum + Math.max(0, q * h - d);
    }, 0);

    const diskonPersen = Math.max(0, Number(currentForm.diskon_persen) || 0);
    const diskonNominal = Math.round((itemsSubtotal * diskonPersen) / 100);
    const dpp = Math.max(0, itemsSubtotal - diskonNominal);

    const pajakPersen = Math.max(0, Number(currentForm.pajak_persen) || 0);
    const pajakNominal = Math.round((dpp * pajakPersen) / 100);

    const totalHarga = dpp + pajakNominal;

    return {
      itemsSubtotal,
      diskonNominal,
      dpp,
      pajakNominal,
      totalHarga,
    };
  };

  // --- Add Form Item Handlers ---
  const addItemRow = () => {
    setForm((f) => ({
      ...f,
      items: [...f.items, { kode_produk: '', qty_pesanan: 1, harga_satuan: 0, diskon: 0 }],
    }));
  };

  const removeItemRow = (idx) => {
    setForm((f) => ({
      ...f,
      items: f.items.filter((_, i) => i !== idx),
    }));
  };

  const updateItemRow = (idx, field, val) => {
    setForm((f) => ({
      ...f,
      items: f.items.map((item, i) => {
        if (i !== idx) return item;
        const updated = { ...item, [field]: val };
        // Otomatis terapkan harga master & rasio kemasan jika ganti produk
        if (field === 'kode_produk') {
          const matched = products.find((p) => p.kode_produk === val);
          if (matched) {
            if (matched.harga !== undefined) updated.harga_satuan = Number(matched.harga);
            const isi = Number(matched.isi_per_kemasan) || 1;
            if (isi > 1) updated.qty_pesanan = isi;
          }
        }
        return updated;
      }),
    }));
  };

  const submitAdd = async (e) => {
    e.preventDefault();
    if (form.items.length === 0) {
      setError('Minimal 1 item produk');
      return;
    }
    setSaving(true);
    setError('');
    try {
      const totals = calculateTotals(form);
      const { data } = await api.post('/sales-orders', {
        ...form,
        customer_id: form.customer_id ? Number(form.customer_id) : null,
        diskon_persen: Number(form.diskon_persen) || 0,
        diskon_nominal: totals.diskonNominal,
        pajak_persen: Number(form.pajak_persen) || 0,
        pajak_nominal: totals.pajakNominal,
        subtotal: totals.itemsSubtotal,
        total_harga: totals.totalHarga,
        items: form.items.map((i) => {
          const q = Number(i.qty_pesanan) || 1;
          const h = Number(i.harga_satuan) || 0;
          const d = Number(i.diskon) || 0;
          return {
            kode_produk: i.kode_produk,
            qty_pesanan: q,
            harga_satuan: h,
            diskon: d,
            subtotal: Math.max(0, q * h - d),
          };
        }),
      });
      flash(data.message);
      toastSuccess(data.message);
      setAddModal(false);
      setForm(emptySoForm);
      loadData();
    } catch (err) {
      const msg = getErrorMessage(err);
      setError(msg);
      alertError('Gagal Membuat SO', msg);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Kop Resmi Khusus Cetak / Print Mode */}
      <div className="hidden print:block">
        <PrintableReportHeader
          companyName={reportConfig.companyName}
          companyAddress={reportConfig.companyAddress}
          companyContact={reportConfig.companyContact}
          companyLogo={reportConfig.companyLogo}
          showCompanyHeader={reportConfig.showCompanyHeader}
          title="LAPORAN REKAPITULASI SALES ORDER (PESANAN PENJUALAN)"
          subtitle={`Status: ${statusFilter || 'Semua Status'} | Per Tanggal: ${formatDate(new Date())}`}
          docNo="REP-SO"
        />
      </div>

      {/* Notifikasi */}
      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 print:hidden">
          <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {success && (
        <div className="flex items-start gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-700 print:hidden">
          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {/* --- Tabel SO --- */}
      <div className="card">
        <div className="card-header flex flex-wrap items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5 text-blue-600" />
            <div>
              <h2 className="text-sm font-semibold text-slate-800">Sales Orders (SO)</h2>
              <p className="text-xs text-slate-500">{sos.length} dokumen SO</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <SearchableSelect
              className="w-36"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              placeholder="Semua Status"
              searchPlaceholder="Cari status..."
              options={[
                { value: '', label: 'Semua Status' },
                { value: 'OPEN', label: 'OPEN' },
                { value: 'PROCESSING', label: 'PROCESSING' },
                { value: 'CLOSED', label: 'CLOSED' },
                { value: 'CANCELLED', label: 'CANCELLED' },
              ]}
            />
            <input
              className="input w-48"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Cari No SO / Customer..."
            />
            <button
              type="button"
              onClick={() => setReportCustomizerOpen(true)}
              className="btn-secondary flex items-center gap-1.5 text-xs font-semibold"
              title="Kustomisasi Kop Perusahaan & Format Cetak"
            >
              <Sliders className="h-3.5 w-3.5 text-blue-600" />
              Kustomisasi
            </button>
            <button
              type="button"
              onClick={() => {
                const headers = ['No. SO', 'Customer', 'Tanggal SO', 'Jatuh Tempo', 'Total Tagihan (Rp)', 'Status Pembayaran', 'Status SO', 'Keterangan'];
                const rows = sos.map((so) => [
                  so.no_so || '',
                  so.nama_customer || '',
                  formatDate(so.tanggal_so),
                  formatDate(so.jatuh_tempo),
                  so.total_harga || 0,
                  so.status_pembayaran || '',
                  so.status || '',
                  so.keterangan || '',
                ]);
                exportToExcel('Rekap_Sales_Orders_SO', headers, rows);
              }}
              className="btn-secondary flex items-center gap-1.5 text-xs font-semibold"
              title="Export Sales Orders ke Excel"
            >
              <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-600" />
              Export Excel
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="btn-secondary flex items-center gap-1.5 text-xs font-semibold"
              title="Cetak Laporan Sales Orders ke PDF"
            >
              <Printer className="h-3.5 w-3.5 text-blue-600" />
              Cetak / Export PDF
            </button>
            <button type="button" onClick={() => setAddModal(true)} className="btn-primary">
              <Plus className="h-4 w-4" /> Buat SO Baru
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex items-center justify-center gap-2 py-10 text-sm text-slate-500">
            <Loader2 className="h-4 w-4 animate-spin" /> Memuat data Sales Orders...
          </div>
        ) : sos.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-slate-500">Belum ada Sales Order.</p>
        ) : (
          (() => {
            const { pageItems, totalPages, safePage } = paginate(sos, page, pageSize);
            return (
              <>
                <div className="overflow-x-auto print:overflow-visible">
                  <table className="table-base print:w-full">
                    <thead>
                      <tr>
                        <th>No SO</th>
                        <th>Customer</th>
                        <th>Tanggal SO</th>
                        <th>Jatuh Tempo</th>
                        <th className="text-right">Total Tagihan</th>
                        <th className="text-center">Status Bayar</th>
                        <th>Status SO</th>
                        <th>Keterangan</th>
                        <th className="print:hidden">
                          <span className="sr-only">Aksi</span>
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {sos.map((so, index) => {
                        const isCurrentPage = index >= (safePage - 1) * pageSize && index < safePage * pageSize;
                        return (
                          <tr key={so.id} className={`hover:bg-slate-50 ${isCurrentPage ? '' : 'hidden print:table-row'}`}>
                            <td className="font-medium text-slate-700">{so.no_so}</td>
                            <td>{so.nama_customer || '-'}</td>
                            <td className="text-xs text-slate-500">{formatDate(so.tanggal_so)}</td>
                            <td className="whitespace-nowrap">
                              <div className="text-xs font-medium text-slate-800">
                                {formatDate(so.jatuh_tempo)}
                              </div>
                              {so.status_pembayaran !== 'LUNAS' && Number(so.total_harga) > 0 && so.hari_terlewat_tempo !== null && (
                                <div className="mt-0.5">
                                  {Number(so.hari_terlewat_tempo) > 0 ? (
                                    <span className="inline-block rounded bg-rose-50 px-1 py-0.2 text-[10px] font-bold text-rose-600">
                                      Lewat {so.hari_terlewat_tempo} hr
                                    </span>
                                  ) : (
                                    <span className="text-[10px] text-slate-500">
                                      Sisa {Math.abs(Number(so.hari_terlewat_tempo))} hr
                                    </span>
                                  )}
                                </div>
                              )}
                            </td>
                            <td className="text-right text-xs font-semibold text-slate-800">
                              {formatRupiah(so.total_harga)}
                            </td>
                            <td className="whitespace-nowrap text-center">
                              {so.status_pembayaran === 'LUNAS' || Number(so.total_harga) <= 0 ? (
                                <span className="badge bg-emerald-100 text-emerald-800">Lunas</span>
                              ) : so.status_pembayaran === 'SEBAGIAN' ? (
                                <div>
                                  <span className="badge bg-blue-100 text-blue-800">Sebagian</span>
                                  <div className="text-[10px] text-slate-500">Sisa {formatRupiah(so.sisa_piutang)}</div>
                                </div>
                              ) : (
                                <div>
                                  <span className="badge bg-rose-100 text-rose-800">Belum Lunas</span>
                                  <div className="text-[10px] text-slate-500">Sisa {formatRupiah(so.sisa_piutang)}</div>
                                </div>
                              )}
                            </td>
                            <td>
                              <span className={`badge ${statusBadges[so.status] || 'bg-slate-100'}`}>
                                {so.status}
                              </span>
                            </td>
                            <td className="max-w-xs truncate text-xs text-slate-500">
                              {so.keterangan || '-'}
                            </td>
                            <td className="print:hidden">
                              <div className="flex justify-end gap-1">
                                <button
                                  type="button"
                                  onClick={() => handlePrintRow(so)}
                                  className="rounded p-1.5 text-blue-600 hover:bg-blue-50 transition"
                                  title="Cetak Surat Pesanan Penjualan (SO)"
                                  aria-label={`Cetak ${so.no_so}`}
                                >
                                  <Printer className="h-4 w-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => openDetail(so.id)}
                                  className="rounded p-1.5 text-slate-500 hover:bg-blue-50 hover:text-blue-600 transition"
                                  title="Lihat Detail SO"
                                  aria-label={`Detail ${so.no_so}`}
                                >
                                  <Eye className="h-4 w-4" />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => deleteSo(so)}
                                  className="rounded p-1.5 text-slate-500 hover:bg-red-50 hover:text-red-600 transition"
                                  title="Hapus SO"
                                  aria-label={`Hapus ${so.no_so}`}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <div className="print:hidden">
                  <Pagination
                    page={safePage}
                    totalPages={totalPages}
                    onPage={setPage}
                    totalItems={sos.length}
                    pageSize={pageSize}
                    onPageSize={(s) => {
                      setPageSize(s);
                      setPage(1);
                    }}
                    label="Sales Orders"
                  />
                </div>

                {/* Blok Tanda Tangan Cetak PDF */}
                <div className="hidden print:block avoid-break mt-6">
                  <PrintableReportSignatures
                    city={reportConfig.signatureCity}
                    date={reportConfig.signatureDate}
                    signer1={reportConfig.signer1}
                    signer2={reportConfig.signer2}
                    signer3={reportConfig.signer3}
                    companyStamp={reportConfig.companyStamp}
                    showStamp={reportConfig.showStamp}
                    stampPosition={reportConfig.stampPosition}
                    showSignatures={reportConfig.showSignatures}
                    footerNote={reportConfig.footerNote}
                  />
                </div>
              </>
            );
          })()
        )}
      </div>

      {/* Modal Kustomisasi Laporan */}
      <ReportCustomizerModal
        isOpen={reportCustomizerOpen}
        onClose={() => setReportCustomizerOpen(false)}
        config={reportConfig}
        onChangeConfig={setReportConfig}
        activeReportTitle="Laporan Sales Orders (SO)"
      />

      {/* --- Modal Detail SO --- */}
      {activeSo && (
        <Modal
          isOpen={detailModal}
          title={`Detail SO: ${activeSo.no_so}`}
          onClose={() => setDetailModal(false)}
          maxWidth="max-w-4xl"
        >
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3 rounded-lg bg-slate-50 p-3 text-xs sm:grid-cols-4">
              <div>
                <span className="text-slate-500">Customer:</span>{' '}
                <strong className="block text-slate-700">{activeSo.nama_customer || '-'}</strong>
              </div>
              <div>
                <span className="text-slate-500">Tanggal SO:</span>{' '}
                <strong className="block text-slate-700">{formatDate(activeSo.tanggal_so)}</strong>
              </div>
              <div>
                <span className="text-slate-500">Status Saat Ini:</span>{' '}
                <div className="mt-0.5">
                  <span className={`badge ${statusBadges[activeSo.status]}`}>
                    {activeSo.status}
                  </span>
                </div>
              </div>
              <div>
                <span className="text-slate-500">Total Tagihan:</span>{' '}
                <strong className="block text-blue-700 text-sm">{formatRupiah(activeSo.total_harga)}</strong>
              </div>
              {activeSo.keterangan && (
                <div className="col-span-2 sm:col-span-4">
                  <span className="text-slate-500">Keterangan:</span>{' '}
                  <span className="text-slate-700">{activeSo.keterangan}</span>
                </div>
              )}
            </div>

            {/* Ubah Status */}
            <div className="flex flex-wrap items-center gap-2 border-t border-b border-slate-100 py-3">
              <span className="text-xs font-medium text-slate-600">Ubah Status SO:</span>
              {['OPEN', 'PROCESSING', 'CLOSED', 'CANCELLED'].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => changeStatus(activeSo.id, st)}
                  disabled={activeSo.status === st}
                  className={`rounded px-2.5 py-1 text-xs font-semibold ${
                    activeSo.status === st
                      ? 'bg-slate-800 text-white'
                      : 'border border-slate-200 text-slate-600 hover:bg-slate-100 disabled:opacity-50'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>

            <h3 className="text-xs font-semibold uppercase text-slate-500">Detail Pesanan Barang</h3>
            <div className="overflow-x-auto">
              <table className="table-base text-xs">
                <thead>
                  <tr>
                    <th>Kode Produk</th>
                    <th>Nama Produk</th>
                    <th className="text-right">Qty Pesanan</th>
                    <th className="text-right">Harga Satuan</th>
                    <th className="text-right">Diskon</th>
                    <th className="text-right">Subtotal</th>
                    <th className="text-right">Qty Terkirim</th>
                  </tr>
                </thead>
                <tbody>
                  {activeSo.details?.map((d) => (
                    <tr key={d.id}>
                      <td className="font-medium text-slate-700">{d.kode_produk}</td>
                      <td>{d.nama_produk || '-'}</td>
                      <td className="text-right font-semibold">
                        <p>{formatNumber(d.qty_pesanan)} {d.satuan || ''}</p>
                        {Number(d.isi_per_kemasan) > 1 && (
                          <p className="text-[11px] text-indigo-600 font-medium">
                            ≈ {formatNumber(Number((d.qty_pesanan / d.isi_per_kemasan).toFixed(1)))} {d.satuan_besar || 'BOX'}
                          </p>
                        )}
                      </td>
                      <td className="text-right">{formatRupiah(d.harga_satuan)}</td>
                      <td className="text-right text-red-600">
                        {Number(d.diskon) > 0 ? `-${formatRupiah(d.diskon)}` : '-'}
                      </td>
                      <td className="text-right font-semibold text-slate-800">{formatRupiah(d.subtotal)}</td>
                      <td className="text-right text-emerald-600 font-semibold">
                        <p>{formatNumber(d.qty_terkirim)} {d.satuan || ''}</p>
                        {Number(d.isi_per_kemasan) > 1 && (
                          <p className="text-[11px] text-emerald-700 font-medium">
                            ≈ {formatNumber(Number((d.qty_terkirim / d.isi_per_kemasan).toFixed(1)))} {d.satuan_besar || 'BOX'}
                          </p>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Rincian Total Biaya */}
            <div className="flex justify-end pt-2">
              <div className="w-full sm:w-80 space-y-1.5 rounded-xl border border-slate-200 bg-slate-50 p-3.5 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal Item:</span>
                  <span className="font-medium">{formatRupiah(activeSo.subtotal)}</span>
                </div>
                {Number(activeSo.diskon_nominal) > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Diskon SO ({Number(activeSo.diskon_persen)}%):</span>
                    <span className="font-medium">-{formatRupiah(activeSo.diskon_nominal)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Pajak PPN ({Number(activeSo.pajak_persen)}%):</span>
                  <span className="font-medium text-blue-600">+{formatRupiah(activeSo.pajak_nominal)}</span>
                </div>
                <div className="flex justify-between border-t border-slate-200 pt-2 text-sm font-bold text-slate-900">
                  <span>Total Tagihan SO:</span>
                  <span className="text-blue-700">{formatRupiah(activeSo.total_harga)}</span>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2">
              <button
                type="button"
                onClick={() => handlePrintRow(activeSo)}
                className="btn-secondary !text-xs flex items-center gap-1.5 text-blue-600 hover:text-blue-700 font-semibold"
                title="Cetak Surat Pesanan Penjualan (SO) Resmi"
              >
                <Printer className="h-4 w-4" /> Cetak Surat Pesanan (SO)
              </button>
              <button type="button" onClick={() => setDetailModal(false)} className="btn-secondary">
                Tutup
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* --- Modal Buat SO Baru --- */}
      <Modal isOpen={addModal} title="Buat Sales Order Baru" onClose={() => setAddModal(false)} maxWidth="max-w-4xl">
        {(() => {
          const totals = calculateTotals(form);
          return (
            <form onSubmit={submitAdd} className="space-y-4">
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div>
                  <label className="label" htmlFor="no_so">Nomor SO (opsional auto)</label>
                  <input
                    id="no_so"
                    className="input"
                    value={form.no_so}
                    onChange={(e) => setForm({ ...form, no_so: e.target.value })}
                    placeholder="Auto jika dikosongkan"
                  />
                </div>
                <div>
                  <label className="label" htmlFor="customer_id">Customer</label>
                  <SearchableSelect
                    id="customer_id"
                    value={form.customer_id}
                    onChange={(e) => setForm({ ...form, customer_id: e.target.value })}
                    placeholder="-- Pilih Customer --"
                    searchPlaceholder="Cari kode atau nama customer..."
                    options={[
                      { value: '', label: '-- Pilih Customer --' },
                      ...customers.map((c) => ({
                        value: c.id,
                        label: `${c.kode_customer} — ${c.nama_customer}`,
                      })),
                    ]}
                  />
                </div>
                <div>
                  <label className="label" htmlFor="tanggal_so">Tanggal SO *</label>
                  <input
                    id="tanggal_so"
                    type="date"
                    className="input"
                    value={form.tanggal_so}
                    onChange={(e) => {
                      const tgl = e.target.value;
                      setForm({
                        ...form,
                        tanggal_so: tgl,
                        jatuh_tempo: calculateDueDate(tgl, form.termin_hari),
                      });
                    }}
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="label" htmlFor="termin_hari_so">Termin Bayar</label>
                    <select
                      id="termin_hari_so"
                      className="input"
                      value={form.termin_hari}
                      onChange={(e) => {
                        const days = Number(e.target.value);
                        setForm({
                          ...form,
                          termin_hari: days,
                          jatuh_tempo: calculateDueDate(form.tanggal_so, days),
                        });
                      }}
                    >
                      <option value="0">Cash / COD</option>
                      <option value="7">Net 7 Hari</option>
                      <option value="14">Net 14 Hari</option>
                      <option value="30">Net 30 Hari</option>
                      <option value="45">Net 45 Hari</option>
                      <option value="60">Net 60 Hari</option>
                    </select>
                  </div>
                  <div>
                    <label className="label" htmlFor="jatuh_tempo_so">Jatuh Tempo *</label>
                    <input
                      id="jatuh_tempo_so"
                      type="date"
                      className="input font-semibold"
                      value={form.jatuh_tempo}
                      onChange={(e) => setForm({ ...form, jatuh_tempo: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <label className="label" htmlFor="keterangan_so">Keterangan</label>
                  <input
                    id="keterangan_so"
                    className="input"
                    value={form.keterangan}
                    onChange={(e) => setForm({ ...form, keterangan: e.target.value })}
                    placeholder="Catatan SO"
                  />
                </div>
              </div>

              <div className="border-t border-slate-100 pt-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase text-slate-500">Daftar Produk Pesanan</span>
                  <button type="button" onClick={addItemRow} className="btn-secondary py-1 text-xs">
                    <PlusCircle className="h-3.5 w-3.5" /> Tambah Baris
                  </button>
                </div>

                {/* Header Kolom Desktop */}
                <div className="hidden sm:flex items-center gap-2 px-1 pb-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  <div className="flex-1">Produk *</div>
                  <div className="w-20 text-center">Qty *</div>
                  <div className="w-32 text-right">Harga Satuan (Rp)</div>
                  <div className="w-24 text-right">Diskon (Rp)</div>
                  <div className="w-28 text-right">Subtotal</div>
                  <div className="w-6"></div>
                </div>

                <div className="space-y-2">
                  {form.items.map((item, idx) => {
                    const lineSubtotal = Math.max(
                      0,
                      (Number(item.qty_pesanan) || 0) * (Number(item.harga_satuan) || 0) - (Number(item.diskon) || 0)
                    );
                    return (
                      <div
                        key={idx}
                        className="rounded-lg border border-slate-200 bg-slate-50/50 p-2.5 space-y-2 sm:space-y-0 sm:flex sm:items-center sm:gap-2 sm:bg-transparent sm:border-0 sm:p-0"
                      >
                        <div className="flex-1 min-w-[200px]">
                          <label className="text-[10px] font-medium text-slate-500 block mb-0.5 sm:hidden">Produk *</label>
                          <SearchableSelect
                            className="w-full text-xs"
                            size="sm"
                            value={item.kode_produk}
                            onChange={(e) => updateItemRow(idx, 'kode_produk', e.target.value)}
                            required
                            placeholder="-- Pilih Produk --"
                            searchPlaceholder="Cari kode atau nama produk..."
                            options={[
                              { value: '', label: '-- Pilih Produk --' },
                              ...products.map((p) => ({
                                value: p.kode_produk,
                                label: `${p.kode_produk} — ${p.nama_produk}`,
                                sublabel: Number(p.isi_per_kemasan) > 1 ? `1 ${p.satuan_besar || 'BOX'} = ${p.isi_per_kemasan} ${p.satuan}` : p.harga ? `Harga master: ${formatRupiah(p.harga)}` : undefined,
                              })),
                            ]}
                          />
                          {(() => {
                            const pObj = products.find((p) => p.kode_produk === item.kode_produk);
                            if (pObj && Number(pObj.isi_per_kemasan) > 1) {
                              return (
                                <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 rounded px-1 py-0.5 mt-1">
                                  1 {pObj.satuan_besar || 'BOX'} = {pObj.isi_per_kemasan} {pObj.satuan}
                                </span>
                              );
                            }
                            return null;
                          })()}
                        </div>
                        <div className="w-full sm:w-28 flex flex-col items-center">
                          <label className="text-[10px] font-medium text-slate-500 block mb-0.5 sm:hidden">Qty Pesanan *</label>
                          <input
                            type="number"
                            min="1"
                            className="input w-full text-xs px-2 py-1.5 sm:text-center font-bold text-indigo-700"
                            value={item.qty_pesanan}
                            onChange={(e) => updateItemRow(idx, 'qty_pesanan', e.target.value)}
                            placeholder="Qty"
                            required
                          />
                          {(() => {
                            const pObj = products.find((p) => p.kode_produk === item.kode_produk);
                            const isi = Number(pObj?.isi_per_kemasan) || 1;
                            if (pObj && isi > 1) {
                              const boxVal = (Number(item.qty_pesanan || 0) / isi).toFixed(2).replace(/\.00$/, '');
                              return (
                                <div className="flex items-center gap-0.5 mt-0.5 text-[10px] text-indigo-600 bg-indigo-50 px-1 py-0.5 rounded border border-indigo-100">
                                  <input
                                    type="number"
                                    min="0.01"
                                    step="any"
                                    value={boxVal}
                                    onChange={(e) => {
                                      const boxNum = Number(e.target.value) || 0;
                                      const calcQty = Math.round(boxNum * isi * 100) / 100;
                                      updateItemRow(idx, 'qty_pesanan', calcQty);
                                    }}
                                    className="w-10 px-1 py-0.5 text-[10px] text-center border border-indigo-200 rounded font-bold bg-white text-indigo-800"
                                  />
                                  <span>{pObj.satuan_besar || 'BOX'}</span>
                                </div>
                              );
                            }
                            return null;
                          })()}
                        </div>
                        <div className="w-full sm:w-32">
                          <label className="text-[10px] font-medium text-slate-500 block mb-0.5 sm:hidden">Harga Satuan (Rp)</label>
                          <input
                            type="number"
                            min="0"
                            step="100"
                            className="input w-full text-xs px-2 py-1.5 sm:text-right"
                            value={item.harga_satuan}
                            onChange={(e) => updateItemRow(idx, 'harga_satuan', e.target.value)}
                            placeholder="0"
                          />
                        </div>
                        <div className="w-full sm:w-24">
                          <label className="text-[10px] font-medium text-slate-500 block mb-0.5 sm:hidden">Diskon Item (Rp)</label>
                          <input
                            type="number"
                            min="0"
                            step="100"
                            className="input w-full text-xs px-2 py-1.5 sm:text-right"
                            value={item.diskon}
                            onChange={(e) => updateItemRow(idx, 'diskon', e.target.value)}
                            placeholder="0"
                          />
                        </div>
                        <div className="w-full sm:w-28 text-right font-semibold text-xs text-slate-700 py-1">
                          <span className="text-[10px] text-slate-400 font-normal mr-1 sm:hidden">Subtotal:</span>
                          {formatRupiah(lineSubtotal)}
                        </div>
                        <div className="w-6 flex justify-end">
                          {form.items.length > 1 && (
                            <button
                              type="button"
                              onClick={() => removeItemRow(idx)}
                              className="rounded p-1 text-red-500 hover:bg-red-50"
                              aria-label="Hapus baris"
                            >
                              <XCircle className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Ringkasan Perhitungan Biaya */}
              <div className="flex justify-end border-t border-slate-100 pt-3">
                <div className="w-full sm:w-80 rounded-xl border border-slate-200 bg-slate-50 p-3.5 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-600">
                    <span>Subtotal Item:</span>
                    <span className="font-semibold">{formatRupiah(totals.itemsSubtotal)}</span>
                  </div>
                  <div className="flex items-center justify-between gap-3 text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <span>Diskon SO (%):</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        className="input w-16 px-1.5 py-1 text-xs text-center"
                        value={form.diskon_persen}
                        onChange={(e) => setForm({ ...form, diskon_persen: e.target.value })}
                        placeholder="0"
                      />
                    </div>
                    <span className="font-medium text-red-600">
                      {totals.diskonNominal > 0 ? `-${formatRupiah(totals.diskonNominal)}` : 'Rp0'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-3 text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <span>Pajak PPN (%):</span>
                      <input
                        type="number"
                        min="0"
                        max="100"
                        className="input w-16 px-1.5 py-1 text-xs text-center"
                        value={form.pajak_persen}
                        onChange={(e) => setForm({ ...form, pajak_persen: e.target.value })}
                        placeholder="0"
                      />
                    </div>
                    <span className="font-medium text-blue-600">
                      {totals.pajakNominal > 0 ? `+${formatRupiah(totals.pajakNominal)}` : 'Rp0'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between border-t border-slate-200 pt-2 text-sm font-bold text-slate-900">
                    <span>Total Tagihan SO:</span>
                    <span className="text-blue-700 text-base">{formatRupiah(totals.totalHarga)}</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 border-t border-slate-100 pt-4">
                <button type="button" onClick={() => setAddModal(false)} className="btn-secondary">
                  Batal
                </button>
                <button type="submit" disabled={saving} className="btn-primary">
                  {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                  Simpan SO
                </button>
              </div>
            </form>
          );
        })()}
      </Modal>
      {/* Modal Cetak Dokumen Surat Pesanan Penjualan (SO) */}
      <PrintableInvoiceModal
        isOpen={invoiceModalOpen}
        onClose={() => setInvoiceModalOpen(false)}
        type="SO"
        data={selectedInvoiceData}
        loading={loadingInvoice}
      />
    </div>
  );
}

