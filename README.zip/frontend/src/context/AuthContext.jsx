import { createContext, useContext, useEffect, useState } from 'react';
import api, { AUTH_KEY, getStoredAuth } from '../services/api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const stored = getStoredAuth();
  const [user, setUser] = useState(stored ? stored.user : null);
  const [loading, setLoading] = useState(Boolean(stored && stored.token));

  // Validasi sesi tersimpan ke server saat aplikasi dibuka
  useEffect(() => {
    if (!stored || !stored.token) return undefined;
    let alive = true;
    (async () => {
      try {
        const { data } = await api.get('/auth/me');
        if (alive) setUser(data.data);
      } catch (_) {
        if (alive) setUser(null);
        try {
          localStorage.removeItem(AUTH_KEY);
        } catch (_) {
          /* abaikan */
        }
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = async (username, password) => {
    const { data } = await api.post('/auth/login', { username, password });
    const auth = { token: data.data.token, user: data.data.user };
    try {
      localStorage.setItem(AUTH_KEY, JSON.stringify(auth));
    } catch (_) {
      /* abaikan */
    }
    setUser(data.data.user);
    return data.data.user;
  };

  const logout = () => {
    try {
      localStorage.removeItem(AUTH_KEY);
    } catch (_) {
      /* abaikan */
    }
    setUser(null);
  };

  const isPengembang = user
    ? (
        ['PENGEMBANG', 'DEVELOPER', 'SUPERADMIN'].includes((user.role || '').toUpperCase()) ||
        user.username === 'admin'
      )
    : false;

  const isAdmin = user
    ? (isPengembang || ['ADMINISTRATOR', 'ADMIN'].includes((user.role || '').toUpperCase()))
    : false;

  return (
    <AuthContext.Provider value={{ user, loading, login, logout, isAdmin, isPengembang }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

export { AuthContext };
